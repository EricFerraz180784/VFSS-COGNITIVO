import os
import re

def apurar_valor_github():
    valor_total_brl = 0.0
    arquivos_processados = 0
    
    # Varre a pasta em busca de todos os logs sincronizados
    for arquivo in os.listdir('.'):
        if arquivo.endswith('.log'):
            arquivos_processados += 1
            with open(arquivo, 'r', encoding='utf-8', errors='ignore') as f:
                conteudo = f.read()
                # Busca por padrões de "TOTAL: R$" ou "CAPTADO: R$" em todo o histórico
                valores = re.findall(r'R\$\s*(\d+\.?\d*,?\d*)', conteudo)
                for v in valores:
                    try:
                        # Limpa a formatação para somar numericamente
                        valor_num = float(v.replace('.', '').replace(',', '.'))
                        # Mantemos apenas o maior valor de cada log como referência de fechamento
                        if valor_num > valor_total_brl:
                            valor_total_brl = valor_num
                    except: continue

    print("=" * 60)
    print("       APURAÇÃO DE CAPTAÇÃO INTEGRAL - GITHUB")
    print("=" * 60)
    print(f" LOGS INDEXADOS:      {arquivos_processados} arquivos")
    print(f" STATUS DE CAPTAÇÃO:  FINALIZADA / SINCRONIZADA")
    print("-" * 60)
    print(f" >> VALOR GERAL (R$):   R$ {valor_total_brl:.2f}")
    print(f" >> VALOR GERAL (USD):  U$ {(valor_total_brl / 5.85):.2f}")
    print(f" >> VALOR GERAL (BTC):  ₿  {(valor_total_brl / 5.85 / 96000):.10f}")
    print("=" * 60)

if __name__ == "__main__":
    apurar_valor_github()
