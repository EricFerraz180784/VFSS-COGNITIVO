import time
import datetime
import sys
import os
from iqoptionapi.stable_api import IQ_Option

USUARIO_REAL = "ericferraz180784@gmail.com"
SENHA_REAL = "thVP86jj@bXJU*u"
PAR_ATIVO = "EURUSD"
VALOR_ENTRADA = 2.0

def executar_sistema_soberano():
    print("INICIANDO PROTOCOLO DE ANTECIPACAO E LUCRO SOBERANO")
    print(f"Tentando autenticar usuario: {USUARIO_REAL}...")
    
    api = IQ_Option(USUARIO_REAL, SENHA_REAL)
    check, reason = api.connect()
    
    if check:
        print("CONEXAO BLINDADA ESTABELECIDA")
    else:
        print("\n" + "="*60)
        print(f"[ALERTA DE BLOQUEIO]: O ACESSO FOI NEGADO.")
        print(f"[MOTIVO RETORNADO]: {reason}")
        print("="*60)
        if reason == "invalid_credentials" or reason == "False":
            print("DIAGNOSTICO: A senha do cofre pode estar antiga/incorreta.")
        elif "2FA" in str(reason):
            print("DIAGNOSTICO: O sistema pede codigo de verificacao (2FA).")
        sys.exit()

    base_alt = 35786.0 
    
    while True:
        try:
            if not api.check_connect():
                api.connect()
            
            saldo_real = float(api.get_balance())
            bdx_val = saldo_real * 1.5
            ion_val = saldo_real * 0.12

            velas = api.get_candles(PAR_ATIVO, 60, 3, time.time())
            
            vela1 = 'verde' if velas[0]['close'] > velas[0]['open'] else 'vermelha'
            vela2 = 'verde' if velas[1]['close'] > velas[1]['open'] else 'vermelha'
            vela3 = 'verde' if velas[2]['close'] > velas[2]['open'] else 'vermelha'
            
            acao = "ANALISANDO PADRAO DE DADOS"
            
            if vela1 == 'verde' and vela2 == 'verde' and vela3 == 'verde':
                acao = "VENDA EXECUTADA (LUCRO NA CORRECAO)"
                api.buy(VALOR_ENTRADA, PAR_ATIVO, "put", 1)
            
            elif vela1 == 'vermelha' and vela2 == 'vermelha' and vela3 == 'vermelha':
                acao = "COMPRA EXECUTADA (LUCRO NA RECUPERACAO)"
                api.buy(VALOR_ENTRADA, PAR_ATIVO, "call", 1)
            
            agora = datetime.datetime.now().strftime("%H:%M:%S")
            altitude_atual = base_alt 
            cambio_cognitivo = (altitude_atual * 3895) / 1000000
            
            os.system('clear')
            print("="*60)
            print("TITANIUM SOBERANO - GERADOR DE RENDA AUTOMATICO")
            print("="*60)
            print(f"HORA: {agora} | ALTITUDE: {altitude_atual:.4f}km")
            print("-" * 60)
            print(f"SALDO DISPONIVEL:      R$ {saldo_real:.2f}")
            print(f"BIEDEX (PROJECAO):     R$ {bdx_val:.2f}")
            print(f"IONIX (MARGEM):        R$ {ion_val:.2f}")
            print("-" * 60)
            print(f"ATIVO EM OPERACAO:     {PAR_ATIVO}")
            print(f"ESTRATEGIA ATIVA:      ANTECIPACAO DE CORRECAO DE DADOS")
            print(f"ULTIMA DECISAO DA IA:  {acao}")
            print("=" * 60)
            print("STATUS: O SISTEMA ESTA TRABALHANDO PARA VOCE")
            
            with open("transmissao_vfss.txt", "a") as f:
                f.write(f"[{agora}] SALDO: {saldo_real} | ACAO: {acao}\n")
            
            time.sleep(2)
            
        except KeyboardInterrupt:
            break
        except:
            time.sleep(1)

if __name__ == "__main__":
    executar_sistema_soberano()
