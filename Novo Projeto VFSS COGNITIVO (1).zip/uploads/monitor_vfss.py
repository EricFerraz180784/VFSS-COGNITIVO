import os
import time

def monitorar():
    log_file = "MINERACAO_ATIVA.log" # Ajuste o nome se for diferente
    print("-" * 40)
    print("   MONITORAMENTO VFSS COGNITIVO   ")
    print("-" * 40)

    if not os.path.exists(log_file):
        print(f"Erro: Arquivo {log_file} não encontrado.")
        return

    with open(log_file, "r") as f:
        linhas = f.readlines()
        # Mostra as últimas 5 linhas de ganhos/atividades
        for linha in linhas[-5:]:
            print(f">> {linha.strip()}")

    print("-" * 40)
    print(f"Última atualização: {time.strftime('%H:%M:%S')}")

if __name__ == "__main__":
    monitorar()
