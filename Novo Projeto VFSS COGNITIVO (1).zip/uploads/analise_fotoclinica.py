import os
import requests
import json
import base64
GEMINI_KEY = os.getenv("GEMINI_API_KEY")
def analisar_imagem_genealogica(path_imagem):
if not GEMINI_KEY:
return "FALHA CHAVE AUSENTE"
if not os.path.exists(path_imagem):
return "FALHA IMAGEM NAO ENCONTRADA"
with open(path_imagem, "rb") as image_file:
encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
url = f"https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key={GEMINI_KEY}"
payload = {
"contents": [{
"parts": [
{"text": "Aja como especialista em Analise Fotoclinica VFSS. Analise os padroes simetricos e evolutivos. Determine o diagnostico clinico de alta precisao SPCN1/5."},
{"inline_data": {"mime_type": "image/png", "data": encoded_string}}
]
}]
}
try:
response = requests.post(url, json=payload, timeout=30)
response.raise_for_status()
data = response.json()
resultado = data['candidates'][0]['content']['parts'][0]['text']
print(resultado)
return "SUCESSO"
except Exception as e:
return f"ERRO {str(e)}"
if name == "main":
analisar_imagem_genealogica("input_clinico.png")
