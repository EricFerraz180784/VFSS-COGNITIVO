import os
import time
from datetime import datetime

def dashboard():
    log_file = "MINERACAO_ATIVA.log" # Nome do seu arquivo de logs

    while True:
        os.system('clear') # Limpa a tela para a nova atualização
        print("=" * 50)
        print(f"       PAINEL VFSS COGNITIVO - NÍVEL 5")
        print(f"       Status: OPERACIONAL | {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
        print("=" * 50)

        if os.path.exists(log_file):
            with open(log_file, "r") as f:
                linhas = f.readlines()
                # Exibe as últimas 10 entradas de ganhos/atividades
                ultimas = linhas[-10:]
                for linha in ultimas:
                    print(f" [GANHO/LOG] > {linha.strip()}")
        else:
            print(f" Aguardando geração de dados em: {log_file}")

        print("=" * 50)
        print(" Pressione Ctrl+C para fechar o monitor.")
        time.sleep(10) # Intervalo de atualização

if __name__ == "__main__":
    try:
        dashboard()
    except KeyboardInterrupt:
        print("\nMonitoramento encerrado.")
