import os

def calcular_financeiro():
    log_file = "MINERACAO_ATIVA.log"
    soma_cambio = 0.0
    contagem = 0

    if not os.path.exists(log_file):
        print("Arquivo de log não encontrado.")
        return

    with open(log_file, "r") as f:
        for linha in f:
            if "CÂMBIO:" in linha:
                try:
                    # Extrai o valor numérico após 'CÂMBIO:'
                    valor = float(linha.split("CÂMBIO:")[1].split("|")[0].strip())
                    soma_cambio += valor
                    contagem += 1
                except:
                    continue

    if contagem > 0:
        media = soma_cambio / contagem
        # Cálculo de rendimento baseado na variação acumulada
        # Ajuste o multiplicador abaixo conforme sua meta (ex: 0.01 para 1%)
        rendimento_estimado = (soma_cambio * 0.00001) 

        print("=" * 45)
        print("       RELATÓRIO FINANCEIRO VFSS")
        print("=" * 45)
        print(f" Ciclos Processados: {contagem}")
        print(f" Média de Câmbio:    {media:.6f}")
        print(f" Rendimento Total:   U$ {rendimento_estimado:.2f}")
        print(f" Valor em Reais:     R$ {rendimento_estimado * 5.80:.2f}") # Cotação estimada
        print("=" * 45)
    else:
        print("Nenhum dado de câmbio encontrado para cálculo.")

if __name__ == "__main__":
    calcular_financeiro()
