import math
import json
import os

class VFSS_Cognitivo:
    def __init__(self, biotipo="Arrojo Cauteloso"):
        self.biotipo_pessoal = biotipo
        self.niveis_alinhamento = 5
        self.operante = True
        self.config_motor = {"assertividade": 1.0, "coerencia": 1.0, "risco_biologico": 0.0}
        self.ifo_historico = [0.056]

    def formula_ifo(self, aceitacao, alinhamento, intervencoes_criticas):
        resultado = (aceitacao * alinhamento) / (intervencoes_criticas + 1)
        self.ifo_historico.append(round(resultado, 4))
        return resultado
