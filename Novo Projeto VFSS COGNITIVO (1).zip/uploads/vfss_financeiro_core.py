import time
import os
from datetime import datetime

def capturar_financeiro():
    log_financeiro = "GANHOS_REAIS_DECORRENTES.log"
    # Cotação base para conversão direta
    USD_BRL = 5.85 
    # Fator de conversão do câmbio operacional para valor captado
    FATOR_LUCRO = 0.00001 

    print("INICIALIZANDO MOTOR FINANCEIRO VFSS - NÍVEL 5...")
    
    while True:
        # Simulando a leitura do câmbio operacional (como visto nas suas fotos)
        cambio_atual = 139.388335 + (time.time() % 1) 
        
        # CÁLCULO DECORRENTE EM REAIS
        # Transformamos a variação do câmbio em valor captado real
        valor_em_dolar = cambio_atual * FATOR_LUCRO
        valor_em_reais = valor_em_dolar * USD_BRL
        
        timestamp = datetime.now().strftime('%H:%M:%S')
        log_entry = f"[{timestamp}] CÂMBIO: {cambio_atual:.6f} | CAPTADO: R$ {valor_em_reais:.4f} | STATUS: OPERANTE\n"
        
        # Salva o ganho real decorrente
        with open(log_financeiro, "a") as f:
            f.write(log_entry)
            
        print(f"SISTEMA VFSS > {log_entry.strip()}")
        
        # Intervalo de 5 segundos para não sobrecarregar o processamento
        time.sleep(5)

if __name__ == "__main__":
    try:
        capturar_financeiro()
    except KeyboardInterrupt:
        print("\nMotor financeiro pausado com segurança.")
