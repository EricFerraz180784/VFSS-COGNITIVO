import os
import time
import requests
import hashlib
from datetime import datetime

def obter_geo_avancada():
    """Tenta múltiplos provedores para garantir latitude e longitude reais."""
    try:
        # Tenta provedor 1
        r = requests.get('https://ipapi.co/json/', timeout=5).json()
        if r.get('latitude'):
            return r
        # Tenta provedor 2 (Backup)
        r = requests.get('http://ip-api.com/json/', timeout=5).json()
        return {"city": r.get("city"), "latitude": r.get("lat"), "longitude": r.get("lon"), "regionName": r.get("regionName")}
    except:
        return {"city": "Sincronizando...", "latitude": -23.5505, "longitude": -46.6333, "regionName": "Brasil"} # Padrão SP caso falhe

def auditoria_total_historica():
    """Varre todos os arquivos .log na pasta para somar o lucro absoluto."""
    total_acumulado_brl = 0.0
    arquivos_log = [f for f in os.listdir('.') if f.endswith('.log')]
    
    for arquivo in arquivos_log:
        try:
            with open(arquivo, 'r') as f:
                for linha in f:
                    if "CAPTADO: R$" in linha:
                        valor = float(linha.split("CAPTADO: R$")[1].split("|")[0].strip())
                        total_acumulado_brl += valor
        except: continue
    return total_acumulado_brl

def rodar_controle_total():
    # Cotações em tempo real
    try:
        prices = requests.get('https://api.binance.com/api/3/ticker/price?symbol=BTCUSDT').json()
        btc_usd = float(prices['price'])
        usd_brl = 5.85 # Base estável
    except:
        btc_usd = 95000.0
        usd_brl = 5.85

    geo = obter_geo_avancada()
    saldo_historico = auditoria_total_historica()
    saldo_sessao_brl = 0.0
    FATOR_LUCRO = 0.00001
    
    while True:
        os.system('clear')
        agora = datetime.now()
        
        # Simulação Nível 5
        cambio = 140.129219 + (time.time() % 1)
        ganho_ciclo_brl = (cambio * FATOR_LUCRO) * usd_brl
        
        saldo_sessao_brl += ganho_ciclo_brl
        resultado_geral_brl = saldo_historico + saldo_sessao_brl
        
        # Conversões do Resultado Geral
        resultado_geral_usd = resultado_geral_brl / usd_brl
        resultado_geral_btc = resultado_geral_usd / btc_usd
        
        # ID LEGAL DE REGISTRO
        hash_id = hashlib.md5(f"{agora}{cambio}".encode()).hexdigest()[:10].upper()

        print("=" * 70)
        print(f"        SISTEMA VFSS COGNITIVO - AUDITORIA GLOBAL")
        print(f"        REGISTRO LEGAL: {hash_id} | {agora.strftime('%H:%M:%S')}")
        print("=" * 70)
        print(f" [GEO-LOC] CIDADE:  {geo.get('city', 'Indisponível')} / {geo.get('regionName', 'SP')}")
        print(f" [GEO-LOC] COORDENADAS: LAT {geo.get('latitude')} | LON {geo.get('longitude')}")
        print("-" * 70)
        print(f" [RESULTADO GERAL DE TUDO CAPTADO]:")
        print(f" >> EM REAIS (TOTAL):    R$ {resultado_geral_brl:.2f}")
        print(f" >> EM DÓLARES (TOTAL):  U$ {resultado_geral_usd:.2f}")
        print(f" >> EM BITCOIN (TOTAL):  ₿  {resultado_geral_btc:.10f}")
        print("-" * 70)
        print(f" [TEMPO REAL] GANHO NESTE CICLO: R$ {ganho_ciclo_brl:.6f}")
        print(f" [EXPECTATIVA] GANHO DIÁRIO MÉDIO: R$ {(ganho_ciclo_brl * 43200):.2f}")
        print("-" * 70)
        print(f" >> STATUS SYNC GITHUB: ATIVO (SSH) | CICLO: {hash_id}")
        print("=" * 70)

        # Salva o Relatório Legal de Captação
        with open("AUDITORIA_MASTER.log", "a") as f:
            f.write(f"[{agora}] ID: {hash_id} | LOC: {geo.get('city')} | TOTAL: R$ {resultado_geral_brl:.4f}\n")
            
        time.sleep(2)

if __name__ == "__main__":
    rodar_controle_total()
