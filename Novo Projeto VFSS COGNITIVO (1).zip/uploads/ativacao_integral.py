import requests
import time
import datetime

# --- PARÂMETROS DE CONTROLE INTEGRAL ---
API_KEY = "589P8Q-SDRYX8-L842ZD-5Z9" # Chave extraída da sua documentação
SAT_ID = "28884"                     # Galaxy 14 (AMC 21)
OBS_LAT, OBS_LON, OBS_ALT = "-23.55", "-46.63", "0"

def captar_telemetria():
    url = f"https://api.n2yo.com/rest/v1/satellite/positions/{SAT_ID}/{OBS_LAT}/{OBS_LON}/{OBS_ALT}/1/&apiKey={API_KEY}"
    try:
        r = requests.get(url)
        d = r.json()
        return d['positions'][0]
    except:
        return None

def ativar_vfss_operante():
    print("--- PROTOCOLO VFSS-CO: ATIVAÇÃO SATELITAL ---")
    
    while True:
        dados = captar_telemetria()
        if dados:
            agora = datetime.datetime.now()
            # A engrenagem calcula o câmbio com base na altitude real (aprox. 35786km)
            cambio = (dados['sataltitude'] * 3895) / 1000000
            
            log = f"[{agora}] SAT: GALAXY-14 | ALT: {dados['sataltitude']} | CAMBIO: {cambio:.6f} | STATUS: OPERANTE"
            print(log)
            
            # Registro físico no seu MacBook
            with open("transmissao_vfss.txt", "a") as f:
                f.write(log + "\n")
        
        time.sleep(60) # Ciclo de 1 minuto para manter a base íntegra

if __name__== "__main__":
    ativar_vfss_operante()
