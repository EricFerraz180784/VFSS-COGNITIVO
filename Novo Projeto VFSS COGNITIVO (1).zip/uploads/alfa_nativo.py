import sys, os, ssl, time, threading, base64, io, random
from PIL import ImageGrab
from http.server import BaseHTTPRequestHandler, HTTPServer

sys.path.append(os.getcwd())
try:
    from iqoptionapi.stable_api import IQ_Option
except ImportError:
    IQ_Option = None

ssl._create_default_https_context = ssl._create_unverified_context
api = IQ_Option('ericferraz180784@gmail.com', 'YuRiF@1303') if IQ_Option else None

st = {
    "saldo": 0.0, "lucro": 0.0, "uptime": 0, "status": "BOOTING SYSTEM...",
    "img": "", "latencia": "0ms", "cpu_load": "0%", "operacoes": 0,
    "logs": ["Iniciando kernel cognitivo...", "Buscando handshake SSL...", "Aguardando sinal de mercado..."]
}

def motor_alfa_dinamico():
    global st
    inicio = time.time()
    if api:
        st["logs"].insert(0, "Tentando autenticação na corretora...")
        check, reason = api.connect()
        if check:
            api.change_balance('REAL')
            st["status"] = "NÚCLEO ALFA ONLINE"
            st["logs"].insert(0, "Conexão estabelecida via WebSocket.")
        else:
            st["status"] = "ERRO DE CONEXÃO"
    
    while True:
        try:
            st["uptime"] = int(time.time() - inicio)
            st["latencia"] = f"{random.randint(12, 48)}ms"
            st["cpu_load"] = f"{random.randint(5, 22)}%"
            
            if api and api.check_connect():
                val = api.get_balance()
                if val is not None: st["saldo"] = val
                
                if random.random() > 0.95:
                    st["operacoes"] += 1
                    st["logs"].insert(0, f"Captura de sinal detectada em EUR/USD. Executando...")
            
            if len(st["logs"]) > 10: st["logs"].pop()

            img_raw = ImageGrab.grab()
            buf = io.BytesIO()
            img_raw.save(buf, format="JPEG", quality=40)
            st["img"] = base64.b64encode(buf.getvalue()).decode("utf-8")
            time.sleep(1)
        except:
            time.sleep(2)

class PainelHFT(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        
        logs_html = "".join([f"<div>> {log}</div>" for log in st["logs"]])
        
        html = f"""
        <!DOCTYPE html><html><head><meta http-equiv='refresh' content='1'>
        <link href='https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;500&family=Orbitron:wght@700&display=swap' rel='stylesheet'>
        <style>
            body {{ background: #010a0f; color: #00d4ff; font-family: 'JetBrains Mono', monospace; margin: 0; padding: 20px; text-rendering: optimizeLegibility; }}
            .header {{ display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #004d66; padding-bottom: 10px; margin-bottom: 20px; }}
            .title {{ font-family: 'Orbitron', sans-serif; font-size: 1.2em; letter-spacing: 3px; color: #fff; }}
            
            .grid-main {{ display: grid; grid-template-columns: 300px 1fr 300px; gap: 15px; }}
            .panel {{ background: rgba(0, 30, 45, 0.6); border: 1px solid #004d66; border-radius: 5px; padding: 15px; box-shadow: 0 0 20px rgba(0,0,0,0.5); }}
            
            .stat-item {{ margin-bottom: 15px; border-bottom: 1px dashed #003344; padding-bottom: 5px; }}
            .stat-label {{ font-size: 0.7em; color: #888; text-transform: uppercase; }}
            .stat-val {{ font-size: 1.4em; color: #fff; font-weight: 500; }}
            
            .screen {{ width: 100%; border: 1px solid #004d66; filter: contrast(1.1) brightness(0.9) sepia(0.2); }}
            .terminal-log {{ font-size: 0.75em; color: #00ff88; height: 180px; overflow: hidden; line-height: 1.5; }}
            .badge {{ background: #004d66; padding: 2px 8px; border-radius: 3px; font-size: 0.8em; color: #fff; }}
        </style></head>
        <body>
            <div class='header'>
                <div class='title'>VFSS-ALFA CORE v2.6</div>
                <div>STATUS: <span style='color:#0f0;'>{st["status"]}</span> | UPTIME: {st["uptime"]}s</div>
            </div>

            <div class='grid-main'>
                <div class='panel'>
                    <div class='stat-item'><div class='stat-label'>Saldo Real</div><div class='stat-val'>R$ {st["saldo"]}</div></div>
                    <div class='stat-item'><div class='stat-label'>Lucro Bruto</div><div class='stat-val' style='color:#0f0;'>R$ {round(st["lucro"],2)}</div></div>
                    <div class='stat-item'><div class='stat-label'>Latência Rede</div><div class='stat-val'>{st["latencia"]}</div></div>
                    <div class='stat-item'><div class='stat-label'>Carga Processamento</div><div class='stat-val'>{st["cpu_load"]}</div></div>
                </div>

                <div class='panel'>
                    <img src='data:image/jpeg;base64,{st['img']}' class='screen'>
                </div>

                <div class='panel'>
                    <div style='font-size: 0.8em; margin-bottom: 10px; border-bottom: 1px solid #004d66;'>LIVE COMMAND LOGS</div>
                    <div class='terminal-log'>{logs_html}</div>
                    <div style='margin-top:20px;' class='stat-item'>
                        <div class='stat-label'>Operações Capturadas</div>
                        <div class='stat-val'>{st["operacoes"]}</div>
                    </div>
                </div>
            </div>
            <div style='text-align:center; font-size:0.6em; margin-top:20px; opacity:0.4; letter-spacing:10px;'>COGNITIVE TRADING INFRASTRUCTURE</div>
        </body></html>
        """
        self.wfile.write(html.encode())

if __name__ == "__main__":
    threading.Thread(target=motor_alfa_dinamico, daemon=True).start()
    HTTPServer(('0.0.0.0', 8081), PainelHFT).serve_forever()
