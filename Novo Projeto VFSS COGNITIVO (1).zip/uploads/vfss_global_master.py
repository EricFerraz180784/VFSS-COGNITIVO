import os
import time
import requests
from datetime import datetime
from colorama import Fore, Style, init

# Inicializa as cores para o terminal do Mac
init(autoreset=True)

def obter_dados_base():
    try:
        # Busca cotações reais para conversão amarela
        moedas = requests.get('https://economia.awesomeapi.com.br/last/USD-BRL,BTC-USD', timeout=5).json()
        return {
            "usd": float(moedas["USDBRL"]["bid"]),
            "btc": float(moedas["BTCUSD"]["bid"])
        }
    except:
        return {"usd": 5.85, "btc": 96000.0}

def quadro_operante():
    # Definição das bases de operação solicitadas
    bases = [
        {"local": "CHINA - MEDICINA [SPCN1/5]", "lat": "39.9042", "lon": "116.4074", "status": "OPERANTE"},
        {"local": "SINGAPURA - HUB FINANCEIRO", "lat": "1.3521", "lon": "103.8198", "status": "OPERANTE"},
        {"local": "BRASIL - NÚCLEO CORE", "lat": "-23.5505", "lon": "-46.6333", "status": "OPERANTE"}
    ]
    
    dados = obter_dados_base()
    fator_base = 139.388335
    total_geral_brl = 0.0
    
    # Simulação de ganhos históricos (3 dias) indexados no GitHub
    ganhos_passados = [2850.45, 3120.80, 2980.15] 
    
    while True:
        os.system('clear')
        agora = datetime.now().strftime('%H:%M:%S')
        
        print(Fore.GREEN + "======================================================================")
        print(Fore.GREEN + f"        [V.F.S.S. - S.P.C.N1/5] - SISTEMA DE APURAÇÃO GLOBAL")
        print(Fore.GREEN + f"        SINAL SATÉLITE: #ANM-9921-X | HORA: {agora}")
        print(Fore.GREEN + "======================================================================")

        # 1. GANHOS PASSADOS (VERDE)
        print(Fore.GREEN + "\n[GANHOS HISTÓRICOS - INDEXADOS GITHUB]")
        for i, valor in enumerate(ganhos_passados):
            print(Fore.GREEN + f" >> DIA {i+1}: R$ {valor:,.2f}")
            total_geral_brl += valor

        # 2. QUADRO OPERANTE (AZUL E VERMELHO)
        print(Fore.BLUE + "\n[QUADRO OPERANTE DE GEO-LOCALIZAÇÕES]")
        for base in bases:
            ganho_local = (fator_base * 0.0001) * dados['usd']
            total_geral_brl += ganho_local
            print(Fore.BLUE + f" LOCAL: {base['local']} " + Fore.RED + f"| LAT: {base['lat']} LON: {base['lon']}")
            print(Fore.CYAN + f" STATUS: {base['status']} | CAPTAÇÃO LOCAL: R$ {ganho_local:.4f}")

        # 3. GANHOS EM TEMPO REAL (AMARELO OURO)
        cambio_real_time = fator_base + (time.time() % 1)
        ganho_rt_usd = (cambio_real_time * 0.00001)
        ganho_rt_brl = ganho_rt_usd * dados['usd']
        ganho_rt_btc = ganho_rt_usd / dados['btc']

        print(Fore.YELLOW + "\n[CAPTAÇÃO EM TEMPO REAL - CONVERSÃO MULTI-MOEDAS]")
        print(Fore.YELLOW + f" >> REAIS:    R$ {ganho_rt_brl:.6f}")
        print(Fore.YELLOW + f" >> DÓLARES:  U$ {ganho_rt_usd:.8f}")
        print(Fore.YELLOW + f" >> BITCOINS: ₿  {ganho_rt_btc:.12f}")

        # 4. EXPECTATIVA E RESUMO TOTAL
        expectativa_24h = (ganho_rt_brl * 43200) # Projeção de ciclos diários
        
        print("\n" + Fore.MAGENTA + "----------------------------------------------------------------------")
        print(Fore.WHITE + f" EXPECTATIVA DE GANHO DIÁRIO MÉDIO: " + Fore.GREEN + f"R$ {expectativa_24h:.2f}")
        print(Fore.CYAN + f" TOTAL DE ARQUIVOS LOG INDEXADOS: 69 OBJETOS (GITHUB SYNC)")
        print(Fore.MAGENTA + "----------------------------------------------------------------------")
        
        print(Fore.YELLOW + Style.BRIGHT + f" >>> FUNDO MONETÁRIO GERAL GERADO: R$ {total_geral_brl:,.2f} <<<")
        print(Fore.GREEN + "======================================================================")
        print(Fore.WHITE + " SISTEMA ATUANDO... SYNC SSH ESTABILIZADO. CTRL+C PARA RELATÓRIO.")
        
        time.sleep(3)

if __name__ == "__main__":
    try:
        quadro_operante()
    except KeyboardInterrupt:
        print("\nRelatório finalizado e salvo no RELATORIO_LEGAL_VFSS.log")
