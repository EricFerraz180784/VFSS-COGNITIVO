# VFSS COGNITIVO - Sistema de Leitura Avançada Global

Dashboard web completo para monitoramento e análise cognitiva de operações de trading, desenvolvido como Progressive Web App (PWA).

## 🚀 Tecnologias

- **Frontend:** React 18 + TypeScript
- **Build Tool:** Vite 5
- **UI Framework:** shadcn/ui + Tailwind CSS
- **State Management:** React Context API
- **Charts:** Recharts
- **Icons:** Lucide React
- **PWA:** Service Worker + Web App Manifest

## 📦 Estrutura do Projeto

```
shadcn-ui/
├── public/              # Arquivos estáticos
│   ├── manifest.json   # PWA manifest
│   └── sw.js           # Service Worker
├── src/
│   ├── components/     # Componentes React
│   │   ├── ui/        # shadcn/ui components
│   │   ├── dashboard/ # Dashboard components
│   │   └── views/     # View components
│   ├── contexts/      # React Context
│   ├── lib/           # Utilitários
│   ├── types/         # TypeScript types
│   └── App.tsx        # App principal
├── index.html         # HTML entry point
├── vite.config.ts     # Vite config
└── package.json       # Dependencies
```

## 🛠️ Instalação e Desenvolvimento

### Pré-requisitos

- Node.js 18+ 
- pnpm (recomendado) ou npm

### Passo 1: Instalar Dependências

```bash
# Usando pnpm (recomendado)
pnpm install

# Ou usando npm
npm install
```

### Passo 2: Rodar em Desenvolvimento

```bash
# Usando pnpm
pnpm run dev

# Ou usando npm
npm run dev
```

O projeto estará disponível em `http://localhost:5173`

### Passo 3: Build de Produção

```bash
# Usando pnpm
pnpm run build

# Ou usando npm
npm run build
```

Os arquivos compilados estarão na pasta `dist/`

### Passo 4: Preview do Build

```bash
# Usando pnpm
pnpm run preview

# Ou usando npm
npm run preview
```

## 🔧 Scripts Disponíveis

```bash
pnpm run dev       # Inicia servidor de desenvolvimento
pnpm run build     # Compila para produção
pnpm run preview   # Preview do build de produção
pnpm run lint      # Executa ESLint
```

## 🌐 Deploy

### Opção 1: Vercel (Recomendado)

1. Crie uma conta em [vercel.com](https://vercel.com)
2. Instale o Vercel CLI: `npm i -g vercel`
3. Na pasta do projeto, execute: `vercel`
4. Siga as instruções no terminal

**Ou via GitHub:**

1. Faça push do código para um repositório GitHub
2. Acesse [vercel.com](https://vercel.com) → "New Project"
3. Importe seu repositório
4. Clique em "Deploy"

### Opção 2: Netlify

1. Faça build: `pnpm run build`
2. Acesse [netlify.com](https://netlify.com)
3. Arraste a pasta `dist/` para fazer deploy

### Opção 3: GitHub Pages

1. Instale: `pnpm add -D gh-pages`
2. Adicione ao `package.json`:
```json
{
  "scripts": {
    "deploy": "gh-pages -d dist"
  }
}
```
3. Execute: `pnpm run build && pnpm run deploy`

## 📱 PWA - Progressive Web App

Este projeto é um PWA completo com:

- ✅ **Instalável** - Pode ser instalado como app nativo
- ✅ **Offline** - Funciona sem internet (cache)
- ✅ **Notificações** - Suporte a push notifications
- ✅ **iOS Support** - Otimizado para iPhone/iPad

### Instalar no iPhone

1. Abra a URL no Safari
2. Toque no ícone de Compartilhar (⬆️)
3. Role para baixo e toque em "Adicionar à Tela de Início"
4. Toque em "Adicionar"

### Instalar no Android

1. Abra a URL no Chrome
2. Um popup aparecerá automaticamente
3. Toque em "Instalar"

## 🔐 Funcionalidades

### Módulos Disponíveis

1. **Dashboard** - Visão geral do sistema
2. **Monitoramento** - Acompanhamento em tempo real
3. **Financeiro** - Análise de saldos e transações
4. **Cognitivo** - Motor de análise cognitiva
5. **Global** - Operações globais
6. **Auditoria** - Logs e histórico
7. **Configurações** - Ajustes do sistema

### Dados em Tempo Real

- Saldo total: R$ 24.860,00
- IQ Option: R$ 5.420,00
- Biedex: R$ 8.640,00
- Ionix Pro: R$ 10.800,00

## 🎨 Customização

### Cores (Tailwind)

Edite `tailwind.config.ts` para personalizar o tema:

```typescript
theme: {
  extend: {
    colors: {
      // Suas cores personalizadas
    }
  }
}
```

### Componentes

Todos os componentes shadcn/ui estão em `src/components/ui/` e podem ser customizados.

## 🐛 Troubleshooting

### Erro: "Module not found"

```bash
# Limpe o cache e reinstale
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

### Erro de Build

```bash
# Execute o lint primeiro
pnpm run lint

# Depois faça o build
pnpm run build
```

### Service Worker não funciona

O Service Worker só funciona em produção (HTTPS). Para testar localmente:

```bash
pnpm run build
pnpm run preview
```

## 📚 Recursos

- [React Documentation](https://react.dev)
- [Vite Documentation](https://vitejs.dev)
- [shadcn/ui Documentation](https://ui.shadcn.com)
- [Tailwind CSS Documentation](https://tailwindcss.com)
- [TypeScript Documentation](https://www.typescriptlang.org)

## 👨‍💻 Desenvolvimento

### Adicionar Nova Página

1. Crie um arquivo em `src/components/views/`
2. Adicione a rota em `src/App.tsx`
3. Adicione o item no `Sidebar.tsx`

### Adicionar Novo Componente shadcn/ui

```bash
# Exemplo: adicionar o componente "calendar"
npx shadcn-ui@latest add calendar
```

## 📄 Licença

Desenvolvido por Valécio Ferreira dos Santos Silva

---

**Dúvidas?** Entre em contato ou abra uma issue no repositório.