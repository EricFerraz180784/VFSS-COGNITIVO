# 🚀 Guia Completo de Deploy - VFSS COGNITIVO

Este guia mostra **3 formas diferentes** de fazer deploy do seu projeto.

---

## 📋 Pré-requisitos

Antes de começar, certifique-se de ter:

- ✅ Git instalado ([download aqui](https://git-scm.com/downloads))
- ✅ Node.js 18+ instalado ([download aqui](https://nodejs.org))
- ✅ Conta no GitHub ([criar conta](https://github.com/signup))
- ✅ Visual Studio Code instalado ([download aqui](https://code.visualstudio.com))

---

## 🎯 Método 1: Deploy via Vercel (Mais Fácil)

### Passo 1: Preparar o Projeto no VS Code

1. **Baixe o projeto:**
   - Clique em "Share" → "Export" na interface MGX
   - Descompacte a pasta no seu computador

2. **Abra no VS Code:**
   - Clique com botão direito na pasta → "Abrir com Code"
   - Ou abra o VS Code e arraste a pasta para dentro

3. **Instale as dependências:**
   ```bash
   # No terminal do VS Code (Ctrl + `)
   pnpm install
   ```

4. **Teste localmente:**
   ```bash
   pnpm run dev
   ```
   Abra `http://localhost:5173` no navegador

### Passo 2: Criar Repositório no GitHub

1. **Inicialize o Git:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit - VFSS COGNITIVO"
   ```

2. **Crie um repositório no GitHub:**
   - Acesse [github.com/new](https://github.com/new)
   - Nome: `vfss-cognitivo`
   - Deixe como "Public"
   - NÃO marque "Add README"
   - Clique em "Create repository"

3. **Conecte e faça push:**
   ```bash
   # Substitua SEU_USUARIO pelo seu username do GitHub
   git remote add origin https://github.com/SEU_USUARIO/vfss-cognitivo.git
   git branch -M main
   git push -u origin main
   ```

### Passo 3: Deploy na Vercel

1. **Acesse [vercel.com](https://vercel.com)**
2. Faça login com sua conta GitHub
3. Clique em "Add New..." → "Project"
4. Selecione o repositório `vfss-cognitivo`
5. Clique em "Deploy"
6. Aguarde ~2 minutos
7. **Pronto!** Você receberá uma URL tipo: `https://vfss-cognitivo.vercel.app`

---

## 🎯 Método 2: Deploy via Netlify

### Passo 1: Build Local

```bash
# No VS Code
pnpm run build
```

Isso criará a pasta `dist/` com os arquivos compilados.

### Passo 2: Deploy Manual

1. **Acesse [netlify.com](https://netlify.com)**
2. Faça login (pode usar GitHub)
3. Clique em "Add new site" → "Deploy manually"
4. **Arraste a pasta `dist/`** para a área de upload
5. Aguarde o deploy
6. **Pronto!** Você receberá uma URL tipo: `https://random-name.netlify.app`

### Passo 3: Personalizar URL (Opcional)

1. Clique em "Site settings"
2. Clique em "Change site name"
3. Digite: `vfss-cognitivo`
4. Salve
5. Nova URL: `https://vfss-cognitivo.netlify.app`

---

## 🎯 Método 3: Deploy via GitHub Pages

### Passo 1: Configurar GitHub Pages

1. **Adicione o script de deploy:**

Abra `package.json` no VS Code e adicione:

```json
{
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "lint": "eslint --quiet ./src",
    "preview": "vite preview",
    "deploy": "gh-pages -d dist"
  }
}
```

2. **Instale gh-pages:**
```bash
pnpm add -D gh-pages
```

3. **Atualize vite.config.ts:**

Adicione a propriedade `base`:

```typescript
export default defineConfig({
  plugins: [react()],
  base: '/vfss-cognitivo/', // Nome do seu repositório
  // ... resto da config
});
```

### Passo 2: Deploy

```bash
# Build e deploy
pnpm run build
pnpm run deploy
```

### Passo 3: Ativar GitHub Pages

1. Acesse seu repositório no GitHub
2. Vá em "Settings" → "Pages"
3. Em "Source", selecione "gh-pages" branch
4. Clique em "Save"
5. Aguarde ~5 minutos
6. **Pronto!** URL: `https://SEU_USUARIO.github.io/vfss-cognitivo/`

---

## 📱 Instalar como PWA no iPhone

Depois do deploy (qualquer método):

1. **Abra a URL no Safari do iPhone**
2. Aguarde 3 segundos - um popup aparecerá
3. **Para iOS:**
   - Toque no ícone de Compartilhar (⬆️)
   - Role para baixo
   - Toque em "Adicionar à Tela de Início"
   - Toque em "Adicionar"

4. **Pronto!** O ícone do VFSS COGNITIVO aparecerá na tela inicial

---

## 🔄 Atualizações Futuras

### Como Atualizar o Site

1. **Faça mudanças no código no VS Code**
2. **Teste localmente:**
   ```bash
   pnpm run dev
   ```

3. **Commit e push:**
   ```bash
   git add .
   git commit -m "Descrição da mudança"
   git push
   ```

4. **Deploy automático:**
   - Vercel: Deploy automático ao fazer push
   - Netlify: Configure "Continuous Deployment" nas settings
   - GitHub Pages: Execute `pnpm run deploy` novamente

---

## 🐛 Problemas Comuns

### "Permission denied" no Git

```bash
# Configure suas credenciais
git config --global user.name "Seu Nome"
git config --global user.email "seu@email.com"
```

### "Module not found" no build

```bash
# Limpe e reinstale
rm -rf node_modules pnpm-lock.yaml
pnpm install
pnpm run build
```

### Site não atualiza após deploy

```bash
# Limpe o cache do navegador
# Ou abra em modo anônimo
```

---

## 📊 Comparação dos Métodos

| Método | Dificuldade | Velocidade | URL Personalizada | Deploy Automático |
|--------|-------------|------------|-------------------|-------------------|
| Vercel | ⭐⭐ Fácil | ⚡ Rápido | ✅ Sim | ✅ Sim |
| Netlify | ⭐ Muito Fácil | ⚡ Rápido | ✅ Sim | ⚠️ Manual |
| GitHub Pages | ⭐⭐⭐ Médio | 🐌 Lento | ⚠️ Limitado | ⚠️ Manual |

**Recomendação:** Use **Vercel** para melhor experiência!

---

## 🎉 Conclusão

Agora você tem 3 formas de fazer deploy do VFSS COGNITIVO!

**Próximos passos:**
1. ✅ Escolha um método acima
2. ✅ Faça o deploy
3. ✅ Teste no iPhone
4. ✅ Instale como PWA
5. ✅ Compartilhe a URL!

**Dúvidas?** Releia este guia ou peça ajuda! 🚀