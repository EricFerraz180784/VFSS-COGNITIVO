import { useState } from 'react';
import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { VFSSProvider } from '@/contexts/VFSSContext';
import { Header } from '@/components/Header';
import { Sidebar } from '@/components/Sidebar';
import { DashboardView } from '@/components/views/DashboardView';
import { MonitoringView } from '@/components/views/MonitoringView';
import { FinancialView } from '@/components/views/FinancialView';
import { CognitiveView } from '@/components/views/CognitiveView';
import { GlobalView } from '@/components/views/GlobalView';
import { AuditView } from '@/components/views/AuditView';
import { SettingsView } from '@/components/views/SettingsView';
import PWAInstallPrompt from '@/components/PWAInstallPrompt';

const queryClient = new QueryClient();

const App = () => {
  const [activeView, setActiveView] = useState('dashboard');

  const renderView = () => {
    switch (activeView) {
      case 'dashboard':
        return <DashboardView />;
      case 'monitoring':
        return <MonitoringView />;
      case 'financial':
        return <FinancialView />;
      case 'cognitive':
        return <CognitiveView />;
      case 'global':
        return <GlobalView />;
      case 'audit':
        return <AuditView />;
      case 'reports':
        return <DashboardView />; // Placeholder
      case 'analytics':
        return <DashboardView />; // Placeholder
      case 'settings':
        return <SettingsView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <QueryClientProvider client={queryClient}>
      <VFSSProvider>
        <TooltipProvider>
          <Toaster />
          <PWAInstallPrompt />
          <div className="min-h-screen bg-[#0A0A0A] text-white">
            <Header />
            <div className="flex h-[calc(100vh-4rem)]">
              <Sidebar activeView={activeView} onViewChange={setActiveView} />
              <main className="flex-1 overflow-auto p-6">
                {renderView()}
              </main>
            </div>
          </div>
        </TooltipProvider>
      </VFSSProvider>
    </QueryClientProvider>
  );
};

export default App;