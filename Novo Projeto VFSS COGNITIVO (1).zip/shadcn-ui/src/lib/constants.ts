// VFSS COGNITIVO - Constants and Configuration

export const VFSS_VERSION = '2.0.0';
export const SYSTEM_NAME = 'VFSS COGNITIVO';
export const PROTOCOL_VERSION = 'SPCN1/5';

export const BIOTIPOS = [
  'Arrojo Cauteloso',
  'Analítico Estratégico',
  'Criativo Resiliente',
  'Pragmático Adaptativo',
  'Visionário Calculista'
] as const;

export const DEFAULT_CONFIG = {
  biotipo_pessoal: 'Arrojo Cauteloso',
  niveis_alinhamento: 5,
  operante: true,
  config_motor: {
    assertividade: 1.0,
    coerencia: 1.0,
    risco_biologico: 0.0
  }
};

export const IFO_INITIAL_VALUE = 0.056;

export const REFRESH_INTERVALS = {
  REAL_TIME: 2000,      // 2 seconds
  METRICS: 5000,        // 5 seconds
  CHARTS: 10000,        // 10 seconds
  AUDIT: 15000          // 15 seconds
};

export const CHART_COLORS = {
  primary: '#00D9FF',
  success: '#00FF88',
  warning: '#FFB800',
  danger: '#FF3366',
  info: '#8B92A8'
};

export const STATUS_COLORS = {
  active: '#00FF88',
  inactive: '#8B92A8',
  warning: '#FFB800',
  error: '#FF3366',
  pending: '#00D9FF'
};

export const MODULES = [
  { id: 'core', name: 'VFSS Core', icon: 'cpu' },
  { id: 'cognitive', name: 'Motor Cognitivo', icon: 'brain' },
  { id: 'financial', name: 'Sistema Financeiro', icon: 'dollar-sign' },
  { id: 'monitoring', name: 'Monitoramento', icon: 'activity' },
  { id: 'audit', name: 'Auditoria', icon: 'shield' },
  { id: 'global', name: 'Operações Globais', icon: 'globe' }
] as const;

export const LOCATIONS = [
  { name: 'Local', country: 'Brasil', coordinates: [-15.7801, -47.9292] },
  { name: 'China', country: 'China', coordinates: [35.8617, 104.1954] },
  { name: 'Singapura', country: 'Singapura', coordinates: [1.3521, 103.8198] },
  { name: 'EUA', country: 'Estados Unidos', coordinates: [37.0902, -95.7129] },
  { name: 'Europa', country: 'União Europeia', coordinates: [50.8503, 4.3517] }
] as const;

export const FLUXOS_REGIONAIS = {
  china: 0.000421,
  singapura: 0.000589,
  europa: 0.000312,
  eua: 0.000445
};

export const CONVERSION_RATE = 5.85;

export const ALERT_THRESHOLDS = {
  ifo_low: 0.03,
  ifo_high: 0.08,
  assertividade_high: 1.5,
  risco_biologico_high: 0.3
};

export const LOG_TYPES = {
  INFO: { color: '#00D9FF', icon: 'info' },
  WARNING: { color: '#FFB800', icon: 'alert-triangle' },
  ERROR: { color: '#FF3366', icon: 'x-circle' },
  SUCCESS: { color: '#00FF88', icon: 'check-circle' }
} as const;

export const SAMPLE_TRANSACTIONS_DATA = `25/12/2025 17:43:18 | ID: C44A11234AD3 | LOC: Local | GANHO: R$ 0.008197 | TOTAL BTC: 0.0000000148
25/12/2025 17:43:20 | ID: 03FFD24839EC | LOC: Local | GANHO: R$ 0.008175 | TOTAL BTC: 0.0000000295
25/12/2025 17:43:22 | ID: 03E287B4F3BD | LOC: Local | GANHO: R$ 0.008200 | TOTAL BTC: 0.0000000442`;

export const API_ENDPOINTS = {
  CORE: '/api/vfss/core',
  FINANCIAL: '/api/vfss/financial',
  MONITORING: '/api/vfss/monitoring',
  AUDIT: '/api/vfss/audit',
  COGNITIVE: '/api/vfss/cognitive'
};