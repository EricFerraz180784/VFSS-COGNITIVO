// VFSS COGNITIVO - Core Engine
// Sistema de Integração Cognitiva Perfeita
// Diretriz: Atuar Globalizadamente / Permanecer Sempre Ativo

import { VFSSConfig, IFOData, CognitiveAnalysis, Transaction } from '@/types/vfss';
import { DEFAULT_CONFIG, IFO_INITIAL_VALUE, FLUXOS_REGIONAIS, CONVERSION_RATE } from './constants';

export class VFSSCognitivo {
  private config: VFSSConfig;
  private ifo_historico: number[];
  private saldo_total_acumulado: number;
  private transactions: Transaction[];
  private start_time: Date;

  constructor(config?: Partial<VFSSConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.ifo_historico = [IFO_INITIAL_VALUE];
    this.saldo_total_acumulado = 734033.73; // Valor registrado na auditoria
    this.transactions = [];
    this.start_time = new Date();
  }

  /**
   * Calcula o Índice de Fluidez Operacional (IFO)
   * Fórmula: (Aceitacao * Alinhamento) / (Intervencoes + 1)
   */
  calcularIFO(aceitacao: number, alinhamento: number, intervencoes_criticas: number): IFOData {
    const resultado = (aceitacao * alinhamento) / (intervencoes_criticas + 1);
    const valor_arredondado = Math.round(resultado * 10000) / 10000;
    
    this.ifo_historico.push(valor_arredondado);
    
    return {
      valor: valor_arredondado,
      timestamp: new Date(),
      aceitacao,
      alinhamento,
      intervencoes_criticas
    };
  }

  /**
   * Módulo CRX: Detecção de Discrepância de Cenário
   */
  moduloCRXAnalise(esforco_real: number): CognitiveAnalysis {
    let status = 'CRX: Operação Estável';
    
    if (this.config.biotipo_pessoal === 'Arrojo Cauteloso' && esforco_real > 0.7) {
      this.config.config_motor.assertividade += 0.2;
      status = 'ALERTA CRX: Resiliência Cognitiva Ativada';
    }

    return {
      biotipo: this.config.biotipo_pessoal,
      esforco_real,
      status_crx: status,
      assertividade: this.config.config_motor.assertividade,
      coerencia: this.config.config_motor.coerencia,
      risco_biologico: this.config.config_motor.risco_biologico
    };
  }

  /**
   * Processa rendimentos de múltiplas regiões
   */
  processarRendimentos(): number {
    const fluxo_china = FLUXOS_REGIONAIS.china;
    const fluxo_singapura = FLUXOS_REGIONAIS.singapura;
    const fluxo_europa = FLUXOS_REGIONAIS.europa;
    const fluxo_eua = FLUXOS_REGIONAIS.eua;

    const ganho_ciclo = (fluxo_china + fluxo_singapura + fluxo_europa + fluxo_eua) * CONVERSION_RATE;
    this.saldo_total_acumulado += ganho_ciclo;

    return ganho_ciclo;
  }

  /**
   * Registra uma nova transação
   */
  registrarTransacao(transaction: Transaction): void {
    this.transactions.push(transaction);
    this.saldo_total_acumulado += transaction.ganho;
  }

  /**
   * Obtém o IFO atual
   */
  getIFOAtual(): number {
    return this.ifo_historico[this.ifo_historico.length - 1];
  }

  /**
   * Obtém histórico de IFO
   */
  getIFOHistorico(): number[] {
    return [...this.ifo_historico];
  }

  /**
   * Obtém saldo total
   */
  getSaldoTotal(): number {
    return this.saldo_total_acumulado;
  }

  /**
   * Obtém configuração atual
   */
  getConfig(): VFSSConfig {
    return { ...this.config };
  }

  /**
   * Atualiza configuração do motor
   */
  atualizarMotor(config: Partial<VFSSConfig['config_motor']>): void {
    this.config.config_motor = { ...this.config.config_motor, ...config };
  }

  /**
   * Obtém tempo de operação (uptime)
   */
  getUptime(): number {
    return Date.now() - this.start_time.getTime();
  }

  /**
   * Obtém todas as transações
   */
  getTransactions(): Transaction[] {
    return [...this.transactions];
  }

  /**
   * Reset do sistema
   */
  reset(): void {
    this.ifo_historico = [IFO_INITIAL_VALUE];
    this.transactions = [];
    this.start_time = new Date();
    this.config = { ...DEFAULT_CONFIG };
  }

  /**
   * Verifica status operacional
   */
  isOperante(): boolean {
    return this.config.operante;
  }

  /**
   * Ativa/Desativa sistema
   */
  setOperante(status: boolean): void {
    this.config.operante = status;
  }

  /**
   * Gera ID único para transação
   */
  static gerarTransactionID(): string {
    return Array.from({ length: 12 }, () => 
      Math.floor(Math.random() * 16).toString(16).toUpperCase()
    ).join('');
  }

  /**
   * Parseia log de transação
   */
  static parseTransactionLog(log: string): Transaction | null {
    const regex = /(\d{2}\/\d{2}\/\d{4}\s+\d{2}:\d{2}:\d{2})\s+\|\s+ID:\s+(\w+)\s+\|\s+LOC:\s+(\w+)\s+\|\s+GANHO:\s+R\$\s+([\d.]+)\s+\|\s+TOTAL BTC:\s+([\d.]+)/;
    const match = log.match(regex);
    
    if (!match) return null;

    const [, timestamp, id, location, ganho, total_btc] = match;
    
    return {
      id,
      timestamp: new Date(timestamp.replace(/(\d{2})\/(\d{2})\/(\d{4})/, '$3-$2-$1')),
      location,
      ganho: parseFloat(ganho),
      total_btc: parseFloat(total_btc)
    };
  }
}

// Instância singleton global
export const vfssInstance = new VFSSCognitivo();