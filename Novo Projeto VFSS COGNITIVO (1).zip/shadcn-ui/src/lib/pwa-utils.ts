// PWA Installation and Service Worker Registration

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export const registerServiceWorker = async () => {
  if ('serviceWorker' in navigator) {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js', {
        scope: '/',
      });
      console.log('Service Worker registered successfully:', registration);
      return registration;
    } catch (error) {
      console.error('Service Worker registration failed:', error);
      return null;
    }
  }
  return null;
};

export const requestNotificationPermission = async () => {
  if ('Notification' in window) {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }
  return false;
};

export const checkPWAInstallable = () => {
  return new Promise((resolve) => {
    let deferredPrompt: BeforeInstallPromptEvent | null = null;

    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredPrompt = e as BeforeInstallPromptEvent;
      resolve(true);
    });

    // Timeout after 3 seconds
    setTimeout(() => {
      if (!deferredPrompt) {
        resolve(false);
      }
    }, 3000);
  });
};

export const installPWA = async () => {
  const deferredPrompt = (window as Window & { deferredPrompt?: BeforeInstallPromptEvent }).deferredPrompt;
  
  if (!deferredPrompt) {
    return false;
  }

  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice;
  
  (window as Window & { deferredPrompt?: BeforeInstallPromptEvent }).deferredPrompt = undefined;
  
  return outcome === 'accepted';
};

// iOS specific PWA detection
export const isIOSPWA = () => {
  return (
    (window.navigator as Navigator & { standalone?: boolean }).standalone === true ||
    window.matchMedia('(display-mode: standalone)').matches
  );
};

export const isIOS = () => {
  return /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as Window & { MSStream?: unknown }).MSStream;
};

// Show iOS install instructions
export const showIOSInstallInstructions = () => {
  if (isIOS() && !isIOSPWA()) {
    return {
      show: true,
      message: 'Para instalar este app no seu iPhone:\n\n1. Toque no ícone de compartilhar (⬆️)\n2. Role para baixo e toque em "Adicionar à Tela de Início"\n3. Toque em "Adicionar"'
    };
  }
  return { show: false, message: '' };
};