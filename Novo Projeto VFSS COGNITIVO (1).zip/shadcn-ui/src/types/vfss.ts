// VFSS COGNITIVO - Type Definitions
// Sistema de Integração Cognitiva Perfeita

export interface VFSSConfig {
  biotipo_pessoal: string;
  niveis_alinhamento: number;
  operante: boolean;
  config_motor: MotorConfig;
}

export interface MotorConfig {
  assertividade: number;
  coerencia: number;
  risco_biologico: number;
}

export interface IFOData {
  valor: number;
  timestamp: Date;
  aceitacao: number;
  alinhamento: number;
  intervencoes_criticas: number;
}

export interface Transaction {
  id: string;
  timestamp: Date;
  location: string;
  ganho: number;
  total_btc: number;
}

export interface SystemStatus {
  operante: boolean;
  ifo_atual: number;
  saldo_total: number;
  total_transacoes: number;
  uptime: number;
  last_update: Date;
}

export interface CognitiveAnalysis {
  biotipo: string;
  esforco_real: number;
  status_crx: string;
  assertividade: number;
  coerencia: number;
  risco_biologico: number;
}

export interface AuditLog {
  id: string;
  timestamp: Date;
  type: 'INFO' | 'WARNING' | 'ERROR' | 'SUCCESS';
  module: string;
  message: string;
  details?: Record<string, unknown>;
}

export interface MetricData {
  label: string;
  value: number;
  change: number;
  trend: 'up' | 'down' | 'stable';
}

export interface GlobalOperation {
  id: string;
  location: string;
  coordinates: [number, number];
  status: 'active' | 'pending' | 'completed';
  value: number;
  timestamp: Date;
}

export interface ChartDataPoint {
  timestamp: string;
  value: number;
  label?: string;
}

export interface NetworkNode {
  id: string;
  label: string;
  type: 'core' | 'module' | 'service';
  status: 'active' | 'inactive' | 'warning';
  connections: string[];
}

export interface APICredentials {
  api_key: string;
  project_ref?: string;
  endpoint: string;
}

export interface ReportConfig {
  type: 'financial' | 'cognitive' | 'audit' | 'performance';
  period: 'daily' | 'weekly' | 'monthly' | 'custom';
  start_date?: Date;
  end_date?: Date;
  format: 'pdf' | 'csv' | 'json';
}