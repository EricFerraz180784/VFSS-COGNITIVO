// VFSS COGNITIVO - Sidebar Navigation

import { 
  LayoutDashboard, 
  Activity, 
  DollarSign, 
  Brain, 
  Shield, 
  Globe, 
  Settings,
  FileText,
  BarChart3
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface SidebarProps {
  activeView: string;
  onViewChange: (view: string) => void;
}

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'monitoring', label: 'Monitoramento', icon: Activity },
  { id: 'financial', label: 'Financeiro', icon: DollarSign },
  { id: 'cognitive', label: 'Motor Cognitivo', icon: Brain },
  { id: 'global', label: 'Operações Globais', icon: Globe },
  { id: 'audit', label: 'Auditoria', icon: Shield },
  { id: 'reports', label: 'Relatórios', icon: FileText },
  { id: 'analytics', label: 'Análises', icon: BarChart3 },
  { id: 'settings', label: 'Configurações', icon: Settings },
];

export function Sidebar({ activeView, onViewChange }: SidebarProps) {
  return (
    <aside className="w-64 border-r border-cyan-500/20 bg-[#0A0A0A] p-4">
      <nav className="space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;
          
          return (
            <Button
              key={item.id}
              variant="ghost"
              className={cn(
                "w-full justify-start gap-3 text-gray-400 hover:text-white hover:bg-cyan-500/10",
                isActive && "bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/20 hover:text-cyan-400"
              )}
              onClick={() => onViewChange(item.id)}
            >
              <Icon className="h-5 w-5" />
              <span>{item.label}</span>
            </Button>
          );
        })}
      </nav>

      <div className="mt-8 p-4 rounded-lg border border-cyan-500/20 bg-[#1A1F2E]">
        <p className="text-xs text-gray-400 mb-2">Protocolo</p>
        <p className="text-sm font-mono text-cyan-400">SPCN1/5</p>
        <p className="text-xs text-gray-400 mt-3 mb-2">Frequência</p>
        <p className="text-sm font-mono text-green-400">14.2 GHz</p>
      </div>
    </aside>
  );
}