import { useState, useEffect } from 'react';
import { X, Download, Share } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { isIOS, isIOSPWA, showIOSInstallInstructions } from '@/lib/pwa-utils';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export default function PWAInstallPrompt() {
  const [showPrompt, setShowPrompt] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);

  useEffect(() => {
    // Check if already installed
    if (isIOSPWA() || window.matchMedia('(display-mode: standalone)').matches) {
      return;
    }

    // iOS Install Prompt
    if (isIOS()) {
      const hasSeenPrompt = localStorage.getItem('pwa-install-prompt-seen');
      if (!hasSeenPrompt) {
        setTimeout(() => setShowPrompt(true), 3000);
      }
      return;
    }

    // Android/Desktop Install Prompt
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      const hasSeenPrompt = localStorage.getItem('pwa-install-prompt-seen');
      if (!hasSeenPrompt) {
        setTimeout(() => setShowPrompt(true), 3000);
      }
    };

    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;

    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;

    if (outcome === 'accepted') {
      setShowPrompt(false);
      localStorage.setItem('pwa-install-prompt-seen', 'true');
    }
    setDeferredPrompt(null);
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    localStorage.setItem('pwa-install-prompt-seen', 'true');
  };

  if (!showPrompt) return null;

  const iosInstructions = showIOSInstallInstructions();

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-end md:items-center justify-center p-4">
      <Card className="w-full max-w-md bg-slate-900 border-slate-700 p-6 animate-in slide-in-from-bottom duration-300">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
              <Download className="w-6 h-6 text-blue-500" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white">Instalar VFSS COGNITIVO</h3>
              <p className="text-sm text-slate-400">Acesso rápido na tela inicial</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleDismiss}
            className="text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        {iosInstructions.show ? (
          <div className="space-y-4">
            <div className="bg-slate-800/50 rounded-lg p-4 space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-500 font-semibold">1</span>
                </div>
                <div className="flex-1">
                  <p className="text-sm text-slate-300">
                    Toque no ícone de <span className="font-semibold text-white">Compartilhar</span>
                  </p>
                  <Share className="w-5 h-5 text-blue-500 mt-2" />
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-500 font-semibold">2</span>
                </div>
                <p className="text-sm text-slate-300 flex-1">
                  Role para baixo e toque em <span className="font-semibold text-white">"Adicionar à Tela de Início"</span>
                </p>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                  <span className="text-blue-500 font-semibold">3</span>
                </div>
                <p className="text-sm text-slate-300 flex-1">
                  Toque em <span className="font-semibold text-white">"Adicionar"</span>
                </p>
              </div>
            </div>
            <Button
              onClick={handleDismiss}
              className="w-full bg-blue-500 hover:bg-blue-600 text-white"
            >
              Entendi
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-slate-300">
                <div className="w-2 h-2 rounded-full bg-green-500"></div>
                <span>Funciona offline</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-300">
                <div className="w-2 h-2 rounded-full bg-green-500"></div>
                <span>Acesso instantâneo</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-slate-300">
                <div className="w-2 h-2 rounded-full bg-green-500"></div>
                <span>Notificações em tempo real</span>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleDismiss}
                variant="outline"
                className="flex-1 border-slate-700 text-slate-300 hover:bg-slate-800"
              >
                Agora não
              </Button>
              <Button
                onClick={handleInstall}
                className="flex-1 bg-blue-500 hover:bg-blue-600 text-white"
              >
                Instalar
              </Button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}