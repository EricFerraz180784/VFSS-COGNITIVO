// VFSS COGNITIVO - Realtime Activity Component

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useVFSS } from '@/contexts/VFSSContext';
import { formatTime, formatCurrency, formatTransactionID } from '@/lib/utils/formatters';
import { Activity } from 'lucide-react';

export function RealtimeActivity() {
  const { transactions } = useVFSS();
  const recentTransactions = transactions.slice(0, 10);

  return (
    <Card className="bg-[#1A1F2E] border-cyan-500/20">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Activity className="h-5 w-5 text-cyan-400" />
          Atividade em Tempo Real
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[300px]">
          <div className="space-y-2">
            {recentTransactions.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-8">
                Aguardando transações...
              </p>
            ) : (
              recentTransactions.map((transaction) => (
                <div
                  key={transaction.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-[#0A0A0A] border border-cyan-500/10 hover:border-cyan-500/30 transition-colors"
                >
                  <div className="flex-1">
                    <p className="text-xs text-gray-400 font-mono">
                      {formatTime(transaction.timestamp)}
                    </p>
                    <p className="text-xs text-cyan-400 font-mono mt-1">
                      ID: {formatTransactionID(transaction.id)}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-green-400 font-mono">
                      {formatCurrency(transaction.ganho)}
                    </p>
                    <p className="text-xs text-gray-400">
                      {transaction.location}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}