// VFSS COGNITIVO - IFO Chart Component

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { vfssInstance } from '@/lib/vfss-core';
import { TrendingUp } from 'lucide-react';

export function IFOChart() {
  const historico = vfssInstance.getIFOHistorico();
  
  const data = historico.slice(-20).map((valor, index) => ({
    index: index + 1,
    ifo: valor
  }));

  return (
    <Card className="bg-[#1A1F2E] border-cyan-500/20">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-cyan-400" />
          Índice de Fluidez Operacional (IFO)
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={250}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#1A1F2E" />
            <XAxis 
              dataKey="index" 
              stroke="#8B92A8"
              style={{ fontSize: '12px' }}
            />
            <YAxis 
              stroke="#8B92A8"
              style={{ fontSize: '12px' }}
              domain={[0, 0.1]}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: '#0A0A0A',
                border: '1px solid #00D9FF',
                borderRadius: '8px',
                color: '#FFFFFF'
              }}
              formatter={(value: number) => [value.toFixed(4), 'IFO']}
            />
            <Line 
              type="monotone" 
              dataKey="ifo" 
              stroke="#00D9FF" 
              strokeWidth={2}
              dot={{ fill: '#00D9FF', r: 3 }}
              activeDot={{ r: 5 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}