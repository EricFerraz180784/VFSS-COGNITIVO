// VFSS COGNITIVO - Metric Card Component

import { LucideIcon } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface MetricCardProps {
  title: string;
  value: string;
  change?: string;
  trend?: 'up' | 'down' | 'stable';
  icon: LucideIcon;
  iconColor?: string;
}

export function MetricCard({ 
  title, 
  value, 
  change, 
  trend = 'stable', 
  icon: Icon,
  iconColor = 'text-cyan-400'
}: MetricCardProps) {
  return (
    <Card className="bg-[#1A1F2E] border-cyan-500/20">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-gray-400">{title}</CardTitle>
        <Icon className={cn("h-5 w-5", iconColor)} />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold text-white font-mono">{value}</div>
        {change && (
          <p className={cn(
            "text-xs mt-1",
            trend === 'up' && "text-green-400",
            trend === 'down' && "text-red-400",
            trend === 'stable' && "text-gray-400"
          )}>
            {change}
          </p>
        )}
      </CardContent>
    </Card>
  );
}