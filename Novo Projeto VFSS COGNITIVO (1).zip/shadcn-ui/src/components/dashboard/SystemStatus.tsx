// VFSS COGNITIVO - System Status Component

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useVFSS } from '@/contexts/VFSSContext';
import { vfssInstance } from '@/lib/vfss-core';
import { CheckCircle2, AlertCircle } from 'lucide-react';

export function SystemStatus() {
  const { isOperante } = useVFSS();
  const config = vfssInstance.getConfig();

  return (
    <Card className="bg-[#1A1F2E] border-cyan-500/20">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          {isOperante ? (
            <CheckCircle2 className="h-5 w-5 text-green-400" />
          ) : (
            <AlertCircle className="h-5 w-5 text-gray-400" />
          )}
          Status do Sistema
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-400">Estado Operacional</span>
          <Badge variant={isOperante ? "default" : "secondary"} className={isOperante ? "bg-green-500" : "bg-gray-500"}>
            {isOperante ? 'ATIVO' : 'INATIVO'}
          </Badge>
        </div>

        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-400">Biotipo</span>
          <span className="text-sm text-white font-mono">{config.biotipo_pessoal}</span>
        </div>

        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-400">Níveis de Alinhamento</span>
          <span className="text-sm text-cyan-400 font-mono">{config.niveis_alinhamento}</span>
        </div>

        <div className="pt-4 border-t border-cyan-500/20">
          <p className="text-xs text-gray-400 mb-2">Configuração do Motor</p>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-xs text-gray-400">Assertividade</span>
              <span className="text-xs text-green-400 font-mono">{config.config_motor.assertividade.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-xs text-gray-400">Coerência</span>
              <span className="text-xs text-green-400 font-mono">{config.config_motor.coerencia.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-xs text-gray-400">Risco Biológico</span>
              <span className="text-xs text-amber-400 font-mono">{config.config_motor.risco_biologico.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}