// VFSS COGNITIVO - Revenue Chart Component

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useVFSS } from '@/contexts/VFSSContext';
import { DollarSign } from 'lucide-react';

interface ChartData {
  time: string;
  revenue: number;
}

export function RevenueChart() {
  const { transactions } = useVFSS();
  
  // Aggregate transactions by time intervals
  const data = transactions.slice(0, 50).reverse().reduce((acc: ChartData[], transaction, index) => {
    if (index % 5 === 0) {
      const sum = transactions.slice(index, index + 5).reduce((s, t) => s + t.ganho, 0);
      acc.push({
        time: `${Math.floor(index / 5) + 1}`,
        revenue: sum
      });
    }
    return acc;
  }, []);

  return (
    <Card className="bg-[#1A1F2E] border-cyan-500/20">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <DollarSign className="h-5 w-5 text-green-400" />
          Receita Acumulada
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={250}>
          <AreaChart data={data}>
            <defs>
              <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#00FF88" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#00FF88" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1A1F2E" />
            <XAxis 
              dataKey="time" 
              stroke="#8B92A8"
              style={{ fontSize: '12px' }}
            />
            <YAxis 
              stroke="#8B92A8"
              style={{ fontSize: '12px' }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: '#0A0A0A',
                border: '1px solid #00FF88',
                borderRadius: '8px',
                color: '#FFFFFF'
              }}
              formatter={(value: number) => [`R$ ${value.toFixed(4)}`, 'Receita']}
            />
            <Area 
              type="monotone" 
              dataKey="revenue" 
              stroke="#00FF88" 
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#colorRevenue)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}