// VFSS COGNITIVO - Header Component

import { Bell, Settings, Power, Activity } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useVFSS } from '@/contexts/VFSSContext';
import { formatUptime } from '@/lib/utils/formatters';

export function Header() {
  const { systemStatus, isOperante, toggleOperante } = useVFSS();

  return (
    <header className="h-16 border-b border-cyan-500/20 bg-[#0A0A0A] px-6 flex items-center justify-between">
      <div className="flex items-center gap-4">
        <img 
          src="https://mgx-backend-cdn.metadl.com/generate/images/877416/2026-01-02/be9b9c21-751e-4ca0-91b3-1ede24dab7fa.png" 
          alt="VFSS Logo" 
          className="h-10 w-10"
        />
        <div>
          <h1 className="text-xl font-bold text-white">VFSS COGNITIVO</h1>
          <p className="text-xs text-cyan-400">Sistema de Leitura Avançada Global v2.0</p>
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <Activity className="h-4 w-4 text-cyan-400" />
          <span className="text-sm text-gray-400">Uptime:</span>
          <span className="text-sm font-mono text-white">{formatUptime(systemStatus.uptime)}</span>
        </div>

        <Badge variant={isOperante ? "default" : "secondary"} className={isOperante ? "bg-green-500" : "bg-gray-500"}>
          {isOperante ? 'OPERANTE' : 'STANDBY'}
        </Badge>

        <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
          <Bell className="h-5 w-5" />
        </Button>

        <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
          <Settings className="h-5 w-5" />
        </Button>

        <Button 
          variant={isOperante ? "destructive" : "default"}
          size="sm"
          onClick={toggleOperante}
          className="gap-2"
        >
          <Power className="h-4 w-4" />
          {isOperante ? 'DESATIVAR' : 'ATIVAR'}
        </Button>
      </div>
    </header>
  );
}