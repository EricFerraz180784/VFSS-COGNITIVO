// VFSS COGNITIVO - Settings View

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Settings, Save, RotateCcw } from 'lucide-react';
import { useState } from 'react';
import { vfssInstance } from '@/lib/vfss-core';
import { useVFSS } from '@/contexts/VFSSContext';
import { BIOTIPOS } from '@/lib/constants';

export function SettingsView() {
  const { addAuditLog } = useVFSS();
  const config = vfssInstance.getConfig();
  
  const [assertividade, setAssertividade] = useState(config.config_motor.assertividade);
  const [coerencia, setCoerencia] = useState(config.config_motor.coerencia);
  const [riscoBiologico, setRiscoBiologico] = useState(config.config_motor.risco_biologico);

  const handleSave = () => {
    vfssInstance.atualizarMotor({
      assertividade,
      coerencia,
      risco_biologico: riscoBiologico
    });

    addAuditLog({
      id: Date.now().toString(),
      timestamp: new Date(),
      type: 'SUCCESS',
      module: 'SETTINGS',
      message: 'Configurações atualizadas com sucesso',
      details: { assertividade, coerencia, risco_biologico: riscoBiologico }
    });
  };

  const handleReset = () => {
    vfssInstance.reset();
    setAssertividade(1.0);
    setCoerencia(1.0);
    setRiscoBiologico(0.0);

    addAuditLog({
      id: Date.now().toString(),
      timestamp: new Date(),
      type: 'WARNING',
      module: 'SETTINGS',
      message: 'Sistema resetado para configurações padrão',
      details: {}
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Settings className="h-8 w-8 text-cyan-400" />
        <div>
          <h2 className="text-2xl font-bold text-white">Configurações do Sistema</h2>
          <p className="text-gray-400">Ajuste os parâmetros do VFSS COGNITIVO</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-[#1A1F2E] border-cyan-500/20">
          <CardHeader>
            <CardTitle className="text-white">Configuração do Motor</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label className="text-gray-400">Assertividade</Label>
              <Input
                type="number"
                step="0.1"
                value={assertividade}
                onChange={(e) => setAssertividade(parseFloat(e.target.value) || 0)}
                className="bg-[#0A0A0A] border-cyan-500/20 text-white"
              />
              <p className="text-xs text-gray-400">Controla o nível de assertividade do sistema (0.0 - 2.0)</p>
            </div>

            <div className="space-y-2">
              <Label className="text-gray-400">Coerência</Label>
              <Input
                type="number"
                step="0.1"
                value={coerencia}
                onChange={(e) => setCoerencia(parseFloat(e.target.value) || 0)}
                className="bg-[#0A0A0A] border-cyan-500/20 text-white"
              />
              <p className="text-xs text-gray-400">Define a coerência operacional (0.0 - 1.0)</p>
            </div>

            <div className="space-y-2">
              <Label className="text-gray-400">Risco Biológico</Label>
              <Input
                type="number"
                step="0.1"
                value={riscoBiologico}
                onChange={(e) => setRiscoBiologico(parseFloat(e.target.value) || 0)}
                className="bg-[#0A0A0A] border-cyan-500/20 text-white"
              />
              <p className="text-xs text-gray-400">Nível de risco biológico aceitável (0.0 - 1.0)</p>
            </div>

            <div className="flex gap-3">
              <Button onClick={handleSave} className="flex-1 bg-green-500 hover:bg-green-600">
                <Save className="h-4 w-4 mr-2" />
                Salvar
              </Button>
              <Button onClick={handleReset} variant="destructive" className="flex-1">
                <RotateCcw className="h-4 w-4 mr-2" />
                Resetar
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1F2E] border-cyan-500/20">
          <CardHeader>
            <CardTitle className="text-white">Informações do Sistema</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-[#0A0A0A] rounded-lg space-y-3">
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Versão</span>
                <span className="text-sm text-white font-mono">2.0.0</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Protocolo</span>
                <span className="text-sm text-cyan-400 font-mono">SPCN1/5</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Biotipo Atual</span>
                <span className="text-sm text-white font-mono">{config.biotipo_pessoal}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Níveis de Alinhamento</span>
                <span className="text-sm text-cyan-400 font-mono">{config.niveis_alinhamento}</span>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-gray-400">Biotipo Disponíveis</Label>
              <Select defaultValue={config.biotipo_pessoal}>
                <SelectTrigger className="bg-[#0A0A0A] border-cyan-500/20 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {BIOTIPOS.map((biotipo) => (
                    <SelectItem key={biotipo} value={biotipo}>
                      {biotipo}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-lg">
              <p className="text-xs text-amber-400">
                ⚠️ Alterações nas configurações do motor podem afetar o desempenho do sistema. 
                Certifique-se de entender os parâmetros antes de modificá-los.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-[#1A1F2E] border-cyan-500/20">
        <CardHeader>
          <CardTitle className="text-white">Propriedade Intelectual</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="p-4 bg-[#0A0A0A] rounded-lg space-y-3">
            <p className="text-sm text-gray-400">
              Sistema VFSS COGNITIVO CORE desenvolvido por Valécio Ferreira dos Santos Silva
            </p>
            <p className="text-sm text-cyan-400 font-mono">
              INPI: 512025007053-5
            </p>
            <p className="text-xs text-gray-400 mt-4">
              Para propostas e consultas: ericferraz180784@gmail.com
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}