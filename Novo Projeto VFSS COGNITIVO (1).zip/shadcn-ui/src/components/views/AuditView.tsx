// VFSS COGNITIVO - Audit View

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { useVFSS } from '@/contexts/VFSSContext';
import { formatDateTime } from '@/lib/utils/formatters';
import { Shield, Info, AlertTriangle, XCircle, CheckCircle } from 'lucide-react';
import { LOG_TYPES } from '@/lib/constants';

export function AuditView() {
  const { auditLogs } = useVFSS();

  const getIcon = (type: string) => {
    switch (type) {
      case 'INFO':
        return <Info className="h-4 w-4" />;
      case 'WARNING':
        return <AlertTriangle className="h-4 w-4" />;
      case 'ERROR':
        return <XCircle className="h-4 w-4" />;
      case 'SUCCESS':
        return <CheckCircle className="h-4 w-4" />;
      default:
        return <Info className="h-4 w-4" />;
    }
  };

  const getColor = (type: string) => {
    switch (type) {
      case 'INFO':
        return 'text-cyan-400 border-cyan-500/50';
      case 'WARNING':
        return 'text-amber-400 border-amber-500/50';
      case 'ERROR':
        return 'text-red-400 border-red-500/50';
      case 'SUCCESS':
        return 'text-green-400 border-green-500/50';
      default:
        return 'text-gray-400 border-gray-500/50';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Shield className="h-8 w-8 text-cyan-400" />
        <div>
          <h2 className="text-2xl font-bold text-white">Sistema de Auditoria</h2>
          <p className="text-gray-400">Registro completo de todas as operações do sistema</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-[#1A1F2E] border-cyan-500/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-400">Total de Logs</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-white font-mono">{auditLogs.length}</p>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1F2E] border-green-500/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-400">Sucessos</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-green-400 font-mono">
              {auditLogs.filter(log => log.type === 'SUCCESS').length}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1F2E] border-amber-500/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-400">Avisos</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-amber-400 font-mono">
              {auditLogs.filter(log => log.type === 'WARNING').length}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1F2E] border-red-500/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-gray-400">Erros</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-red-400 font-mono">
              {auditLogs.filter(log => log.type === 'ERROR').length}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-[#1A1F2E] border-cyan-500/20">
        <CardHeader>
          <CardTitle className="text-white">Log de Auditoria</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[600px]">
            <div className="space-y-2">
              {auditLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-4 bg-[#0A0A0A] rounded-lg border border-cyan-500/10 hover:border-cyan-500/30 transition-colors"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className={getColor(log.type)}>
                        {getIcon(log.type)}
                        <span className="ml-1">{log.type}</span>
                      </Badge>
                      <Badge variant="outline" className="border-cyan-500/50 text-cyan-400">
                        {log.module}
                      </Badge>
                    </div>
                    <span className="text-xs text-gray-400 font-mono">
                      {formatDateTime(log.timestamp)}
                    </span>
                  </div>
                  
                  <p className="text-sm text-white mb-2">{log.message}</p>
                  
                  {log.details && (
                    <div className="mt-2 p-2 bg-[#1A1F2E] rounded text-xs text-gray-400 font-mono">
                      {JSON.stringify(log.details, null, 2)}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}