// VFSS COGNITIVO - Cognitive Engine View

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { useState } from 'react';
import { vfssInstance } from '@/lib/vfss-core';
import { useVFSS } from '@/contexts/VFSSContext';
import { Brain, Zap, AlertTriangle, CheckCircle } from 'lucide-react';
import { formatNumber } from '@/lib/utils/formatters';

export function CognitiveView() {
  const { addAuditLog } = useVFSS();
  const [aceitacao, setAceitacao] = useState(0.8);
  const [alinhamento, setAlinhamento] = useState(0.9);
  const [intervencoes, setIntervencoes] = useState(2);
  const [esforcoReal, setEsforcoReal] = useState(0.5);
  const [ifoResult, setIfoResult] = useState<number | null>(null);
  const [crxResult, setCrxResult] = useState<string | null>(null);

  const calcularIFO = () => {
    const result = vfssInstance.calcularIFO(aceitacao, alinhamento, intervencoes);
    setIfoResult(result.valor);
    
    addAuditLog({
      id: Date.now().toString(),
      timestamp: new Date(),
      type: 'SUCCESS',
      module: 'COGNITIVE',
      message: `IFO calculado: ${result.valor.toFixed(4)}`,
      details: { aceitacao, alinhamento, intervencoes }
    });
  };

  const executarCRX = () => {
    const result = vfssInstance.moduloCRXAnalise(esforcoReal);
    setCrxResult(result.status_crx);
    
    addAuditLog({
      id: Date.now().toString(),
      timestamp: new Date(),
      type: result.status_crx.includes('ALERTA') ? 'WARNING' : 'INFO',
      module: 'CRX',
      message: result.status_crx,
      details: { esforco_real: esforcoReal, assertividade: result.assertividade }
    });
  };

  const config = vfssInstance.getConfig();

  return (
    <div className="space-y-6">
      <div className="relative h-48 rounded-lg overflow-hidden">
        <img 
          src="https://mgx-backend-cdn.metadl.com/generate/images/877416/2026-01-02/440526d5-6948-40e7-841f-33d54f57d01c.png"
          alt="Cognitive Brain"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-transparent flex items-center px-8">
          <div>
            <h2 className="text-3xl font-bold text-white mb-2">Motor Cognitivo</h2>
            <p className="text-cyan-400">Análise Avançada e Processamento Inteligente</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-[#1A1F2E] border-cyan-500/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Brain className="h-5 w-5 text-cyan-400" />
              Calculadora IFO
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label className="text-gray-400">Aceitação: {formatNumber(aceitacao, 2)}</Label>
              <Slider
                value={[aceitacao]}
                onValueChange={(value) => setAceitacao(value[0])}
                min={0}
                max={1}
                step={0.01}
                className="w-full"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-gray-400">Alinhamento: {formatNumber(alinhamento, 2)}</Label>
              <Slider
                value={[alinhamento]}
                onValueChange={(value) => setAlinhamento(value[0])}
                min={0}
                max={1}
                step={0.01}
                className="w-full"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-gray-400">Intervenções Críticas</Label>
              <Input
                type="number"
                value={intervencoes}
                onChange={(e) => setIntervencoes(parseInt(e.target.value) || 0)}
                className="bg-[#0A0A0A] border-cyan-500/20 text-white"
              />
            </div>

            <Button onClick={calcularIFO} className="w-full bg-cyan-500 hover:bg-cyan-600">
              <Zap className="h-4 w-4 mr-2" />
              Calcular IFO
            </Button>

            {ifoResult !== null && (
              <div className="p-4 bg-[#0A0A0A] rounded-lg border border-cyan-500/30">
                <p className="text-sm text-gray-400 mb-1">Resultado IFO</p>
                <p className="text-3xl font-bold text-cyan-400 font-mono">{formatNumber(ifoResult, 4)}</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-[#1A1F2E] border-amber-500/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-400" />
              Módulo CRX
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label className="text-gray-400">Esforço Real: {formatNumber(esforcoReal, 2)}</Label>
              <Slider
                value={[esforcoReal]}
                onValueChange={(value) => setEsforcoReal(value[0])}
                min={0}
                max={1}
                step={0.01}
                className="w-full"
              />
            </div>

            <div className="p-4 bg-[#0A0A0A] rounded-lg space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Biotipo Atual</span>
                <span className="text-sm text-white font-mono">{config.biotipo_pessoal}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-400">Assertividade</span>
                <span className="text-sm text-green-400 font-mono">{formatNumber(config.config_motor.assertividade, 2)}</span>
              </div>
            </div>

            <Button onClick={executarCRX} className="w-full bg-amber-500 hover:bg-amber-600">
              <AlertTriangle className="h-4 w-4 mr-2" />
              Executar Análise CRX
            </Button>

            {crxResult && (
              <div className={`p-4 rounded-lg border ${crxResult.includes('ALERTA') ? 'bg-amber-500/10 border-amber-500/30' : 'bg-green-500/10 border-green-500/30'}`}>
                <p className="text-sm font-mono text-white">{crxResult}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="bg-[#1A1F2E] border-cyan-500/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-400" />
            Configuração do Motor
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-4 bg-[#0A0A0A] rounded-lg">
              <p className="text-sm text-gray-400 mb-2">Assertividade</p>
              <p className="text-2xl font-bold text-green-400 font-mono">{formatNumber(config.config_motor.assertividade, 2)}</p>
              <div className="mt-3 h-2 bg-gray-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-green-400 transition-all"
                  style={{ width: `${(config.config_motor.assertividade / 2) * 100}%` }}
                />
              </div>
            </div>

            <div className="p-4 bg-[#0A0A0A] rounded-lg">
              <p className="text-sm text-gray-400 mb-2">Coerência</p>
              <p className="text-2xl font-bold text-cyan-400 font-mono">{formatNumber(config.config_motor.coerencia, 2)}</p>
              <div className="mt-3 h-2 bg-gray-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-cyan-400 transition-all"
                  style={{ width: `${config.config_motor.coerencia * 100}%` }}
                />
              </div>
            </div>

            <div className="p-4 bg-[#0A0A0A] rounded-lg">
              <p className="text-sm text-gray-400 mb-2">Risco Biológico</p>
              <p className="text-2xl font-bold text-amber-400 font-mono">{formatNumber(config.config_motor.risco_biologico, 2)}</p>
              <div className="mt-3 h-2 bg-gray-700 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-amber-400 transition-all"
                  style={{ width: `${config.config_motor.risco_biologico * 100}%` }}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}