// VFSS COGNITIVO - Main Dashboard View

import { MetricCard } from '@/components/dashboard/MetricCard';
import { SystemStatus } from '@/components/dashboard/SystemStatus';
import { RealtimeActivity } from '@/components/dashboard/RealtimeActivity';
import { IFOChart } from '@/components/dashboard/IFOChart';
import { RevenueChart } from '@/components/dashboard/RevenueChart';
import { useVFSS } from '@/contexts/VFSSContext';
import { formatCurrency, formatNumber } from '@/lib/utils/formatters';
import { DollarSign, Activity, TrendingUp, Database } from 'lucide-react';

export function DashboardView() {
  const { systemStatus, transactions } = useVFSS();

  const totalGanhos = transactions.reduce((sum, t) => sum + t.ganho, 0);
  const mediaGanho = transactions.length > 0 ? totalGanhos / transactions.length : 0;

  return (
    <div className="space-y-6">
      {/* Hero Section */}
      <div className="relative h-48 rounded-lg overflow-hidden">
        <img 
          src="https://mgx-backend-cdn.metadl.com/generate/images/877416/2026-01-02/788a59bb-4692-43eb-94ff-0b486b420fb4.png"
          alt="Neural Network"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-transparent flex items-center px-8">
          <div>
            <h2 className="text-3xl font-bold text-white mb-2">Sistema VFSS COGNITIVO</h2>
            <p className="text-cyan-400">Leitura Avançada Global em Operação</p>
          </div>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Saldo Total"
          value={formatCurrency(systemStatus.saldo_total)}
          change="+2.4% hoje"
          trend="up"
          icon={DollarSign}
          iconColor="text-green-400"
        />
        <MetricCard
          title="IFO Atual"
          value={formatNumber(systemStatus.ifo_atual, 4)}
          change="Estável"
          trend="stable"
          icon={TrendingUp}
          iconColor="text-cyan-400"
        />
        <MetricCard
          title="Transações"
          value={systemStatus.total_transacoes.toString()}
          change={`Média: ${formatCurrency(mediaGanho)}`}
          trend="up"
          icon={Activity}
          iconColor="text-amber-400"
        />
        <MetricCard
          title="Operações Ativas"
          value={systemStatus.operante ? 'ONLINE' : 'OFFLINE'}
          change={`${transactions.length} registros`}
          trend={systemStatus.operante ? 'up' : 'down'}
          icon={Database}
          iconColor={systemStatus.operante ? 'text-green-400' : 'text-gray-400'}
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <IFOChart />
        <RevenueChart />
      </div>

      {/* Activity and Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <RealtimeActivity />
        </div>
        <div>
          <SystemStatus />
        </div>
      </div>
    </div>
  );
}