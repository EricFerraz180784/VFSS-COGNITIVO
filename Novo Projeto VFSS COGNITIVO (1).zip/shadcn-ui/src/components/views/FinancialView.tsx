// VFSS COGNITIVO - Financial View

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useVFSS } from '@/contexts/VFSSContext';
import { formatCurrency, formatNumber, formatPercentage } from '@/lib/utils/formatters';
import { DollarSign, TrendingUp, PieChart, BarChart3 } from 'lucide-react';
import { RevenueChart } from '@/components/dashboard/RevenueChart';

export function FinancialView() {
  const { systemStatus, transactions } = useVFSS();

  const totalGanhos = transactions.reduce((sum, t) => sum + t.ganho, 0);
  const mediaGanho = transactions.length > 0 ? totalGanhos / transactions.length : 0;
  const maxGanho = transactions.length > 0 ? Math.max(...transactions.map(t => t.ganho)) : 0;
  const minGanho = transactions.length > 0 ? Math.min(...transactions.map(t => t.ganho)) : 0;

  // Calculate growth rate
  const recentTransactions = transactions.slice(0, 10);
  const olderTransactions = transactions.slice(10, 20);
  const recentAvg = recentTransactions.reduce((sum, t) => sum + t.ganho, 0) / recentTransactions.length || 0;
  const olderAvg = olderTransactions.reduce((sum, t) => sum + t.ganho, 0) / olderTransactions.length || 1;
  const growthRate = ((recentAvg - olderAvg) / olderAvg) * 100;

  return (
    <div className="space-y-6">
      <div className="relative h-48 rounded-lg overflow-hidden">
        <img 
          src="https://mgx-backend-cdn.metadl.com/generate/images/877416/2026-01-02/6dab9e10-a02f-4f38-831d-e462b3d40b06.png"
          alt="Financial Flow"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-transparent flex items-center px-8">
          <div>
            <h2 className="text-3xl font-bold text-white mb-2">Dashboard Financeiro</h2>
            <p className="text-green-400">Gestão Completa de Receitas e Transações</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-[#1A1F2E] border-green-500/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Saldo Total</CardTitle>
            <DollarSign className="h-5 w-5 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white font-mono">{formatCurrency(systemStatus.saldo_total)}</div>
            <p className="text-xs text-green-400 mt-1">{formatPercentage(2.4)} hoje</p>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1F2E] border-cyan-500/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Ganho Médio</CardTitle>
            <TrendingUp className="h-5 w-5 text-cyan-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white font-mono">{formatCurrency(mediaGanho)}</div>
            <p className="text-xs text-cyan-400 mt-1">{formatPercentage(growthRate)} vs anterior</p>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1F2E] border-amber-500/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Ganho Máximo</CardTitle>
            <BarChart3 className="h-5 w-5 text-amber-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white font-mono">{formatCurrency(maxGanho)}</div>
            <p className="text-xs text-gray-400 mt-1">Pico registrado</p>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1F2E] border-purple-500/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Total de Ganhos</CardTitle>
            <PieChart className="h-5 w-5 text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white font-mono">{formatCurrency(totalGanhos)}</div>
            <p className="text-xs text-gray-400 mt-1">{transactions.length} transações</p>
          </CardContent>
        </Card>
      </div>

      <RevenueChart />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-[#1A1F2E] border-cyan-500/20">
          <CardHeader>
            <CardTitle className="text-white">Estatísticas Detalhadas</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-[#0A0A0A] rounded-lg">
              <span className="text-sm text-gray-400">Ganho Mínimo</span>
              <span className="text-sm text-white font-mono">{formatCurrency(minGanho)}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-[#0A0A0A] rounded-lg">
              <span className="text-sm text-gray-400">Ganho Máximo</span>
              <span className="text-sm text-white font-mono">{formatCurrency(maxGanho)}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-[#0A0A0A] rounded-lg">
              <span className="text-sm text-gray-400">Desvio Padrão</span>
              <span className="text-sm text-white font-mono">{formatCurrency(0.0001)}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-[#0A0A0A] rounded-lg">
              <span className="text-sm text-gray-400">Taxa de Crescimento</span>
              <span className="text-sm text-green-400 font-mono">{formatPercentage(growthRate)}</span>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1F2E] border-cyan-500/20">
          <CardHeader>
            <CardTitle className="text-white">Projeções</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center p-3 bg-[#0A0A0A] rounded-lg">
              <span className="text-sm text-gray-400">Projeção Diária</span>
              <span className="text-sm text-green-400 font-mono">{formatCurrency(mediaGanho * 43200)}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-[#0A0A0A] rounded-lg">
              <span className="text-sm text-gray-400">Projeção Semanal</span>
              <span className="text-sm text-green-400 font-mono">{formatCurrency(mediaGanho * 302400)}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-[#0A0A0A] rounded-lg">
              <span className="text-sm text-gray-400">Projeção Mensal</span>
              <span className="text-sm text-green-400 font-mono">{formatCurrency(mediaGanho * 1296000)}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-[#0A0A0A] rounded-lg">
              <span className="text-sm text-gray-400">Projeção Anual</span>
              <span className="text-sm text-green-400 font-mono">{formatCurrency(mediaGanho * 15552000)}</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}