// VFSS COGNITIVO - Global Operations View

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Globe, MapPin, Radio } from 'lucide-react';
import { LOCATIONS, FLUXOS_REGIONAIS } from '@/lib/constants';
import { formatNumber } from '@/lib/utils/formatters';

export function GlobalView() {
  return (
    <div className="space-y-6">
      <div className="relative h-48 rounded-lg overflow-hidden">
        <img 
          src="https://mgx-backend-cdn.metadl.com/generate/images/877416/2026-01-02/a2999a04-c580-40f4-ba22-c5ca2c6ff02a.png"
          alt="Global Network"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-transparent flex items-center px-8">
          <div>
            <h2 className="text-3xl font-bold text-white mb-2">Operações Globais</h2>
            <p className="text-cyan-400">Monitoramento de Rede Mundial</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-[#1A1F2E] border-cyan-500/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">China</CardTitle>
            <MapPin className="h-5 w-5 text-red-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white font-mono">{formatNumber(FLUXOS_REGIONAIS.china, 6)}</div>
            <p className="text-xs text-green-400 mt-1">Medicina Cognitiva</p>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1F2E] border-cyan-500/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Singapura</CardTitle>
            <MapPin className="h-5 w-5 text-cyan-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white font-mono">{formatNumber(FLUXOS_REGIONAIS.singapura, 6)}</div>
            <p className="text-xs text-green-400 mt-1">Hub Financeiro</p>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1F2E] border-cyan-500/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Europa</CardTitle>
            <MapPin className="h-5 w-5 text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white font-mono">{formatNumber(FLUXOS_REGIONAIS.europa, 6)}</div>
            <p className="text-xs text-green-400 mt-1">Tecnologia Avançada</p>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1F2E] border-cyan-500/20">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">EUA</CardTitle>
            <MapPin className="h-5 w-5 text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white font-mono">{formatNumber(FLUXOS_REGIONAIS.eua, 6)}</div>
            <p className="text-xs text-green-400 mt-1">Inovação Digital</p>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-[#1A1F2E] border-cyan-500/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Globe className="h-5 w-5 text-cyan-400" />
            Localizações Ativas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {LOCATIONS.map((location) => (
              <div
                key={location.name}
                className="p-4 bg-[#0A0A0A] rounded-lg border border-cyan-500/10 hover:border-cyan-500/30 transition-colors"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <MapPin className="h-5 w-5 text-cyan-400" />
                    <div>
                      <p className="text-white font-semibold">{location.name}</p>
                      <p className="text-sm text-gray-400">{location.country}</p>
                    </div>
                  </div>
                  <Badge className="bg-green-500">ATIVO</Badge>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-gray-400 mb-1">Coordenadas</p>
                    <p className="text-sm text-cyan-400 font-mono">
                      {location.coordinates[0].toFixed(4)}, {location.coordinates[1].toFixed(4)}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 mb-1">Status de Sinal</p>
                    <div className="flex items-center gap-2">
                      <Radio className="h-4 w-4 text-green-400 animate-pulse" />
                      <span className="text-sm text-green-400">100%</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-[#1A1F2E] border-cyan-500/20">
        <CardHeader>
          <CardTitle className="text-white">Protocolo de Comunicação</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-[#0A0A0A] rounded-lg">
            <div className="flex justify-between mb-2">
              <span className="text-sm text-gray-400">Protocolo</span>
              <span className="text-sm text-cyan-400 font-mono">SPCN1/5</span>
            </div>
            <div className="flex justify-between mb-2">
              <span className="text-sm text-gray-400">Frequência</span>
              <span className="text-sm text-green-400 font-mono">14.2 GHz</span>
            </div>
            <div className="flex justify-between mb-2">
              <span className="text-sm text-gray-400">Latência</span>
              <span className="text-sm text-green-400 font-mono">12ms</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-400">Integridade</span>
              <span className="text-sm text-green-400 font-mono">VERIFIED</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}