// VFSS COGNITIVO - Monitoring View

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { useVFSS } from '@/contexts/VFSSContext';
import { formatDateTime, formatCurrency, formatBTC } from '@/lib/utils/formatters';
import { Activity, MapPin, Clock } from 'lucide-react';

export function MonitoringView() {
  const { transactions } = useVFSS();

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Activity className="h-8 w-8 text-cyan-400" />
        <div>
          <h2 className="text-2xl font-bold text-white">Monitoramento em Tempo Real</h2>
          <p className="text-gray-400">Acompanhamento de todas as operações do sistema</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="bg-[#1A1F2E] border-cyan-500/20">
          <CardHeader>
            <CardTitle className="text-white text-sm">Total de Operações</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-cyan-400 font-mono">{transactions.length}</p>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1F2E] border-cyan-500/20">
          <CardHeader>
            <CardTitle className="text-white text-sm">Ganho Total</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-green-400 font-mono">
              {formatCurrency(transactions.reduce((sum, t) => sum + t.ganho, 0))}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-[#1A1F2E] border-cyan-500/20">
          <CardHeader>
            <CardTitle className="text-white text-sm">BTC Acumulado</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-amber-400 font-mono">
              {transactions.length > 0 ? formatBTC(transactions[0].total_btc) : '0.0000000000 BTC'}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-[#1A1F2E] border-cyan-500/20">
        <CardHeader>
          <CardTitle className="text-white">Log de Transações</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[600px]">
            <div className="space-y-2">
              {transactions.map((transaction) => (
                <div
                  key={transaction.id}
                  className="p-4 rounded-lg bg-[#0A0A0A] border border-cyan-500/10 hover:border-cyan-500/30 transition-colors"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="border-cyan-500/50 text-cyan-400">
                        {transaction.id}
                      </Badge>
                      <Badge variant="outline" className="border-green-500/50 text-green-400">
                        <MapPin className="h-3 w-3 mr-1" />
                        {transaction.location}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-gray-400 text-xs">
                      <Clock className="h-3 w-3" />
                      {formatDateTime(transaction.timestamp)}
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mt-3">
                    <div>
                      <p className="text-xs text-gray-400 mb-1">Ganho</p>
                      <p className="text-lg font-mono text-green-400">{formatCurrency(transaction.ganho)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400 mb-1">Total BTC</p>
                      <p className="text-sm font-mono text-amber-400">{formatBTC(transaction.total_btc)}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}