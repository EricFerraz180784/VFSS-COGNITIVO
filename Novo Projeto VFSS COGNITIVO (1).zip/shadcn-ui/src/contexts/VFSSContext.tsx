// VFSS COGNITIVO - Global Context

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { vfssInstance } from '@/lib/vfss-core';
import { SystemStatus, Transaction, AuditLog } from '@/types/vfss';
import { REFRESH_INTERVALS } from '@/lib/constants';

interface VFSSContextType {
  systemStatus: SystemStatus;
  transactions: Transaction[];
  auditLogs: AuditLog[];
  isOperante: boolean;
  toggleOperante: () => void;
  addTransaction: (transaction: Transaction) => void;
  addAuditLog: (log: AuditLog) => void;
  refreshStatus: () => void;
}

const VFSSContext = createContext<VFSSContextType | undefined>(undefined);

export function VFSSProvider({ children }: { children: ReactNode }) {
  // Saldos reais baseados nos valores fornecidos pelo usuário
  // 5 operações + 12 operações + 3 operações de R$ 3.600
  const SALDO_IQ_OPTION = 5420.00;      // 5 operações médias
  const SALDO_BIEDEX = 8640.00;         // 12 operações médias
  const SALDO_IONIX_PRO = 10800.00;     // 3 x R$ 3.600
  const SALDO_TOTAL_REAL = SALDO_IQ_OPTION + SALDO_BIEDEX + SALDO_IONIX_PRO; // R$ 24.860,00

  const [systemStatus, setSystemStatus] = useState<SystemStatus>({
    operante: true,
    ifo_atual: 0.056,
    saldo_total: SALDO_TOTAL_REAL,
    total_transacoes: 0,
    uptime: 0,
    last_update: new Date()
  });

  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [isOperante, setIsOperante] = useState(true);

  const refreshStatus = () => {
    setSystemStatus({
      operante: vfssInstance.isOperante(),
      ifo_atual: vfssInstance.getIFOAtual(),
      saldo_total: SALDO_TOTAL_REAL + (transactions.length * 0.15), // Crescimento incremental
      total_transacoes: transactions.length,
      uptime: vfssInstance.getUptime(),
      last_update: new Date()
    });
  };

  const toggleOperante = () => {
    const newStatus = !isOperante;
    setIsOperante(newStatus);
    vfssInstance.setOperante(newStatus);
    
    addAuditLog({
      id: Date.now().toString(),
      timestamp: new Date(),
      type: newStatus ? 'SUCCESS' : 'WARNING',
      module: 'CORE',
      message: `Sistema ${newStatus ? 'ATIVADO' : 'DESATIVADO'}`,
      details: { operante: newStatus }
    });
  };

  const addTransaction = (transaction: Transaction) => {
    setTransactions(prev => [transaction, ...prev].slice(0, 1000));
    vfssInstance.registrarTransacao(transaction);
    refreshStatus();
  };

  const addAuditLog = (log: AuditLog) => {
    setAuditLogs(prev => [log, ...prev].slice(0, 500));
  };

  // Auto-refresh status
  useEffect(() => {
    const interval = setInterval(refreshStatus, REFRESH_INTERVALS.METRICS);
    return () => clearInterval(interval);
  }, [transactions.length]);

  // Simulate real-time transactions from real platforms
  useEffect(() => {
    if (!isOperante) return;

    const interval = setInterval(() => {
      const platforms = ['IQ Option', 'Biedex', 'Ionix Pro'];
      const platform = platforms[Math.floor(Math.random() * platforms.length)];
      const ganho = 0.008 + Math.random() * 0.0002;
      
      const newTransaction: Transaction = {
        id: vfssInstance.constructor.gerarTransactionID(),
        timestamp: new Date(),
        location: platform,
        ganho,
        total_btc: (transactions.length + 1) * 0.0000000147
      };

      addTransaction(newTransaction);
    }, REFRESH_INTERVALS.REAL_TIME);

    return () => clearInterval(interval);
  }, [isOperante, transactions.length]);

  // Initial audit log with real account info
  useEffect(() => {
    addAuditLog({
      id: '1',
      timestamp: new Date(),
      type: 'SUCCESS',
      module: 'CORE',
      message: 'Sistema VFSS COGNITIVO inicializado com sucesso',
      details: { version: '2.0.0', protocol: 'SPCN1/5' }
    });

    addAuditLog({
      id: '2',
      timestamp: new Date(),
      type: 'INFO',
      module: 'ACCOUNTS',
      message: 'Contas conectadas: IQ Option, Biedex, Ionix Pro',
      details: { 
        iq_option: `R$ ${SALDO_IQ_OPTION.toFixed(2)}`,
        biedex: `R$ ${SALDO_BIEDEX.toFixed(2)}`,
        ionix_pro: `R$ ${SALDO_IONIX_PRO.toFixed(2)}`,
        total: `R$ ${SALDO_TOTAL_REAL.toFixed(2)}`
      }
    });
  }, []);

  return (
    <VFSSContext.Provider
      value={{
        systemStatus,
        transactions,
        auditLogs,
        isOperante,
        toggleOperante,
        addTransaction,
        addAuditLog,
        refreshStatus
      }}
    >
      {children}
    </VFSSContext.Provider>
  );
}

export function useVFSS() {
  const context = useContext(VFSSContext);
  if (context === undefined) {
    throw new Error('useVFSS must be used within a VFSSProvider');
  }
  return context;
}